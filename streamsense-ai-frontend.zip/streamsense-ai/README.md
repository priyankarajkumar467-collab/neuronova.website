# StreamSense AI — Frontend

**Containerized OTT Audience Segmentation & Personalization Service**
*"Every Viewer Has a Pattern. We Make It Visible."*

A hackathon-grade, presentation-ready frontend for an unsupervised audience
segmentation product. Built with **React + TypeScript + Tailwind CSS +
Recharts + Lucide**, with a centralized API layer so the real FastAPI
backend (Trainer → API → Evaluator) can be wired in without touching any
component.

---

## Quick start

```bash
npm install
cp .env.example .env      # adjust if connecting a real backend
npm run dev
```

Open the printed local URL (default `http://localhost:5173`).

## Demo Mode vs Live API Mode

Everything numeric in this app is either clearly labeled **Demo Data**
(mock, for presentation only) or **Live API** (from your real backend).
Nothing is silently fabricated.

- **Demo Mode (default)** — `VITE_APP_MODE=demo`. All persona, model and
  evaluation data comes from the single centralized file
  `src/data/demoData.ts`. The "Discover Viewer" flow uses a transparent,
  clearly-labeled local heuristic (`src/utils/simulate.ts`) instead of a
  real trained model, so the demo is still interactive without a backend.
- **Live API Mode** — set:
  ```
  VITE_APP_MODE=live
  VITE_API_BASE_URL=http://localhost:8000
  ```
  All calls then go through `src/api/client.ts` to your real FastAPI
  service (`GET /health`, `POST /recommend`, and an evaluator metrics
  endpoint). No component code needs to change.

To fully go live, replace the demo values inside
`src/context/AppDataContext.tsx` (personas, model info, K-evaluation
curve, evaluation report) with real fetches — that file is the single
seam between "mock" and "real."

## Project structure

```
src/
  api/            Centralized API layer (client.ts) — the ONLY place that calls fetch()
  context/        AppDataContext — single source of truth for demo/live data
  data/           demoData.ts — the ONLY file holding mock/demo values
  types/          Shared TypeScript contracts (mirrors the real backend schema)
  utils/          simulate.ts (demo-mode heuristic), compass.ts (rule-based mapping)
  components/
    layout/       Sidebar, TopBar, AppShell
    common/       GlassCard, DataBadge, StatusPill, Logo
    persona/      Persona orb field, persona detail panel, Behavior DNA
    viewer/       Digital Twin, Fingerprint radar, Why This Persona, Persona Shift Lab, Compass
    model/        K-selection charts, cluster balance, feature matrix, persona battle, evaluation, edge cases
    charts/       Audience Universe scatter, radar fingerprint
  judge/          JudgeMode.tsx — guided presentation overlay
  pages/          One file per nav item (Intelligence Hub, Persona Universe, Discover Viewer,
                  Recommendation Studio, Model Lab, System Pulse, Project Story)
```

## Backend contract this frontend expects

```
GET  /health        -> { "status": "ok", "model_loaded": true }
POST /recommend      body: { user_id, watch_time_hours, top_genres, avg_session_mins }
                     -> { user_id, segment_id, segment_name, recommendations, distance_to_centroid }
```

These are schema examples only — the frontend never treats example values
as real results, and always displays "Demo Data" / "Awaiting Model" /
"Awaiting Evaluation" / "API Offline" until real values are available.

## Honesty guardrails baked into the UI

- No cluster count, silhouette score, inertia, viewer count, or evaluation
  result is ever hardcoded outside `src/data/demoData.ts`.
- `distance_to_centroid` is never presented as a confidence percentage.
- The Audience Universe plot is only labeled "PCA" when real PCA
  coordinates are supplied; otherwise it's labeled as a feature-based plot.
- Recommendations are explicitly described as "Explainable Rule-Based
  Personalization," never as collaborative filtering or deep learning.
- Evaluation dimensions and edge cases default to `NOT EVALUATED` /
  `NOT TESTED` rather than assuming a pass.

## Judge Mode

Click **▶ Judge Mode** in the top bar for a guided, 10-step walkthrough of
the full story — problem → discovery → personas → live viewer demo →
explanation → recommendation → evidence → engineering. It navigates the
real app; it does not alter any data.

## Build

```bash
npm run build
npm run preview
```
