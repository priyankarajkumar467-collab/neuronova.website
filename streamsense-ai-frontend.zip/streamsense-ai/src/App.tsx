import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AppDataProvider } from './context/AppDataContext';
import AppShell from './components/layout/AppShell';
import IntelligenceHub from './pages/IntelligenceHub';
import PersonaUniversePage from './pages/PersonaUniversePage';
import DiscoverViewer from './pages/DiscoverViewer';
import RecommendationStudio from './pages/RecommendationStudio';
import ModelLab from './pages/ModelLab';
import SystemPulse from './pages/SystemPulse';
import ProjectStory from './pages/ProjectStory';

export const App: React.FC = () => {
  return (
    <BrowserRouter>
      <AppDataProvider>
        <Routes>
          <Route element={<AppShell />}>
            <Route index element={<IntelligenceHub />} />
            <Route path="personas" element={<PersonaUniversePage />} />
            <Route path="discover" element={<DiscoverViewer />} />
            <Route path="studio" element={<RecommendationStudio />} />
            <Route path="model-lab" element={<ModelLab />} />
            <Route path="system-pulse" element={<SystemPulse />} />
            <Route path="story" element={<ProjectStory />} />
          </Route>
        </Routes>
      </AppDataProvider>
    </BrowserRouter>
  );
};

export default App;
