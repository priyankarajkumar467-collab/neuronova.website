// ============================================================
// StreamSense AI — Centralized API Layer
// ------------------------------------------------------------
// This is the ONLY file that should ever call `fetch` against the
// backend. Every page/component goes through the functions below.
//
// Swapping DEMO MODE -> LIVE API MODE requires no component changes:
// set VITE_API_BASE_URL and VITE_APP_MODE=live in your .env file.
// ============================================================

import type { HealthResponse, RecommendRequest, RecommendResponse } from '../types';

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? '';
export const APP_MODE = (import.meta.env.VITE_APP_MODE ?? 'demo') as 'demo' | 'live';

export const isLiveMode = () => APP_MODE === 'live' && !!API_BASE_URL;

class ApiError extends Error {
  status?: number;
  constructor(message: string, status?: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  if (!isLiveMode()) {
    throw new ApiError('API is not connected. Running in DEMO MODE.');
  }
  let res: Response;
  try {
    res = await fetch(`${API_BASE_URL}${path}`, {
      headers: { 'Content-Type': 'application/json' },
      ...init
    });
  } catch (err) {
    throw new ApiError('Network failure while reaching the StreamSense API.');
  }
  if (!res.ok) {
    throw new ApiError(`API responded with an error (${res.status}).`, res.status);
  }
  return (await res.json()) as T;
}

/** GET /health — never assumes containers are healthy beyond what this reports. */
export async function fetchHealth(): Promise<HealthResponse> {
  return request<HealthResponse>('/health');
}

/** POST /recommend — assigns a segment + returns explainable recommendations. */
export async function postRecommend(payload: RecommendRequest): Promise<RecommendResponse> {
  return request<RecommendResponse>('/recommend', {
    method: 'POST',
    body: JSON.stringify(payload)
  });
}

/** GET /metrics (or wherever the Evaluator publishes metrics.json) */
export async function fetchEvaluationReport<T>(): Promise<T> {
  return request<T>('/metrics');
}

export { ApiError };
