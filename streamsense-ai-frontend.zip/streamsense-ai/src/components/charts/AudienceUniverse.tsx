import React, { useMemo } from 'react';
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid
} from 'recharts';
import type { Persona, Viewer } from '../../types';

const PALETTE = ['#4fd8e0', '#8b7cf6', '#f5b95e', '#f47b9c', '#4fe0a8', '#7dd3fc', '#c4b5fd'];

export const AudienceUniverse: React.FC<{ viewers: Viewer[]; personas: Persona[] }> = ({
  viewers,
  personas
}) => {
  const isPCA = viewers[0]?.projection?.isPCA ?? false;

  const byCluster = useMemo(() => {
    const map = new Map<number, Viewer[]>();
    viewers.forEach((v) => {
      if (!map.has(v.clusterId)) map.set(v.clusterId, []);
      map.get(v.clusterId)!.push(v);
    });
    return map;
  }, [viewers]);

  return (
    <div>
      <ResponsiveContainer width="100%" height={380}>
        <ScatterChart margin={{ top: 10, right: 20, bottom: 10, left: 0 }}>
          <CartesianGrid stroke="rgba(255,255,255,0.06)" />
          <XAxis
            type="number"
            dataKey="x"
            name={isPCA ? 'PCA Component 1' : 'Watch Time (hrs)'}
            tick={{ fill: '#64748b', fontSize: 11 }}
            stroke="rgba(255,255,255,0.1)"
          />
          <YAxis
            type="number"
            dataKey="y"
            name={isPCA ? 'PCA Component 2' : 'Avg Session (mins)'}
            tick={{ fill: '#64748b', fontSize: 11 }}
            stroke="rgba(255,255,255,0.1)"
          />
          <ZAxis range={[40, 40]} />
          <Tooltip
            cursor={{ strokeDasharray: '3 3' }}
            content={({ active, payload }) => {
              if (!active || !payload?.length) return null;
              const v = payload[0].payload as Viewer;
              const persona = personas.find((p) => p.clusterId === v.clusterId);
              return (
                <div className="glass-panel px-3 py-2 text-xs">
                  <p className="font-mono text-slate-300">{v.userId}</p>
                  <p className="text-slate-400">Persona: {persona?.name ?? `Cluster ${v.clusterId}`}</p>
                  <p className="text-slate-400">Watch time: {v.watchTimeHours}h</p>
                  <p className="text-slate-400">Session: {v.avgSessionMins}m</p>
                  <p className="text-slate-400">Genre: {v.topGenres.join(', ')}</p>
                </div>
              );
            }}
          />
          {[...byCluster.entries()].map(([clusterId, points]) => (
            <Scatter
              key={clusterId}
              name={personas.find((p) => p.clusterId === clusterId)?.name ?? `Cluster ${clusterId}`}
              data={points.map((v) => ({ ...v, x: v.projection?.x ?? 0, y: v.projection?.y ?? 0 }))}
              fill={PALETTE[clusterId % PALETTE.length]}
              fillOpacity={0.75}
            />
          ))}
        </ScatterChart>
      </ResponsiveContainer>
      <p className="mt-2 text-center font-mono text-[10px] uppercase tracking-wider text-slate-500">
        {isPCA ? 'PCA 2D Projection' : 'Feature-Based Plot (Watch Time × Session Duration) — not PCA'}
      </p>
    </div>
  );
};

export default AudienceUniverse;
