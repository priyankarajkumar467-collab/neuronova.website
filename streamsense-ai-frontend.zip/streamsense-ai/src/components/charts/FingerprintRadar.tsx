import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, ResponsiveContainer } from 'recharts';
import type { BehaviorFeatureVector, FeatureKey } from '../../types';
import { FEATURE_LABELS } from '../../types';

const ORDER: FeatureKey[] = [
  'engagement',
  'sessionDepth',
  'frequency',
  'genreDiversity',
  'completion',
  'exploration',
  'weekendActivity'
];

export const FingerprintRadar: React.FC<{ features: BehaviorFeatureVector; color?: string }> = ({
  features,
  color = '#4fd8e0'
}) => {
  const data = ORDER.filter((k) => typeof features[k] === 'number').map((k) => ({
    dimension: FEATURE_LABELS[k],
    value: Math.round((features[k] as number) * 100)
  }));

  if (data.length < 3) {
    return (
      <p className="text-sm text-slate-500">
        Not enough behavioral dimensions available to render a fingerprint yet.
      </p>
    );
  }

  return (
    <ResponsiveContainer width="100%" height={280}>
      <RadarChart data={data} outerRadius="72%">
        <PolarGrid stroke="rgba(255,255,255,0.08)" />
        <PolarAngleAxis dataKey="dimension" tick={{ fill: '#94a3b8', fontSize: 10.5 }} />
        <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fill: '#475569', fontSize: 9 }} />
        <Radar dataKey="value" stroke={color} fill={color} fillOpacity={0.28} strokeWidth={2} />
      </RadarChart>
    </ResponsiveContainer>
  );
};

export default FingerprintRadar;
