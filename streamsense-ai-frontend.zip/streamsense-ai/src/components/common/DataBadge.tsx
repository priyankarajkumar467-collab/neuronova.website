import React from 'react';
import { FlaskConical, Radio } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';

/** Always render this next to any surface showing numbers that could be mock data. */
export const DataBadge: React.FC<{ label?: string }> = ({ label }) => {
  const { source } = useAppData();
  if (source === 'live') {
    return (
      <span className="badge-live">
        <Radio size={11} /> {label ?? 'Live API'}
      </span>
    );
  }
  return (
    <span className="badge-demo">
      <FlaskConical size={11} /> {label ?? 'Demo Data'}
    </span>
  );
};

export const AwaitingBadge: React.FC<{ label: string }> = ({ label }) => (
  <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] px-2.5 py-1 text-[10px] font-mono uppercase tracking-wider text-slate-400">
    {label}
  </span>
);

export default DataBadge;
