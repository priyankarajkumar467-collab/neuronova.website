import React from 'react';
import clsx from '../../utils/clsx';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
  as?: 'div' | 'section';
}

export const GlassCard: React.FC<GlassCardProps> = ({ children, className, as = 'div' }) => {
  const Comp = as as any;
  return <Comp className={clsx('glass-panel', className)}>{children}</Comp>;
};

export default GlassCard;
