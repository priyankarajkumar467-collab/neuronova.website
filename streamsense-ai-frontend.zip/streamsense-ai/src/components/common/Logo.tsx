import React from 'react';

export const LogoMark: React.FC<{ size?: number }> = ({ size = 34 }) => (
  <svg width={size} height={size} viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="ss-grad" x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
        <stop stopColor="#4fd8e0" />
        <stop offset="1" stopColor="#8b7cf6" />
      </linearGradient>
    </defs>
    <rect x="0.5" y="0.5" width="39" height="39" rx="11" stroke="url(#ss-grad)" strokeOpacity="0.35" />
    {/* concentric fingerprint arcs merging into a streaming waveform */}
    <path
      d="M8 24c2-5 4-9 8-9s6 4 8 9 6 9 10 9"
      stroke="url(#ss-grad)"
      strokeWidth="1.6"
      strokeLinecap="round"
      fill="none"
      opacity="0.55"
    />
    <path
      d="M8 20c2-6 5-11 9-11s5.5 5 9 11 6 11 10 11"
      stroke="url(#ss-grad)"
      strokeWidth="1.6"
      strokeLinecap="round"
      fill="none"
      opacity="0.85"
    />
    <path
      d="M6 16c3-6 6-9 10-9s6 3 8 9 5 9 10 9"
      stroke="url(#ss-grad)"
      strokeWidth="2"
      strokeLinecap="round"
      fill="none"
    />
  </svg>
);

export const Logo: React.FC = () => (
  <div className="flex items-center gap-2.5">
    <LogoMark />
    <div className="leading-tight">
      <p className="font-display text-[15px] font-semibold tracking-tight text-slate-50">
        StreamSense <span className="text-gradient">AI</span>
      </p>
      <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-slate-500">Audience Intelligence</p>
    </div>
  </div>
);

export default Logo;
