import React from 'react';
import type { ServiceStatus } from '../../types';
import clsx from '../../utils/clsx';

const STYLES: Record<ServiceStatus, string> = {
  online: 'bg-signal-emerald/10 text-signal-emerald border-signal-emerald/30',
  offline: 'bg-signal-rose/10 text-signal-rose border-signal-rose/30',
  degraded: 'bg-signal-amber/10 text-signal-amber border-signal-amber/30',
  loading: 'bg-signal-cyan/10 text-signal-cyan border-signal-cyan/30',
  unknown: 'bg-slate-500/10 text-slate-400 border-slate-500/30'
};

const DOT: Record<ServiceStatus, string> = {
  online: 'bg-signal-emerald',
  offline: 'bg-signal-rose',
  degraded: 'bg-signal-amber',
  loading: 'bg-signal-cyan animate-pulse',
  unknown: 'bg-slate-500'
};

export const StatusPill: React.FC<{ label: string; status: ServiceStatus }> = ({ label, status }) => (
  <span
    className={clsx(
      'inline-flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium',
      STYLES[status]
    )}
  >
    <span className={clsx('h-1.5 w-1.5 rounded-full', DOT[status])} />
    {label}
    <span className="opacity-70 capitalize">· {status}</span>
  </span>
);

export default StatusPill;
