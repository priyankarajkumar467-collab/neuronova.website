import React, { useState } from 'react';
import { Outlet, NavLink } from 'react-router-dom';
import { X } from 'lucide-react';
import Sidebar from './Sidebar';
import TopBar from './TopBar';
import Logo from '../common/Logo';
import clsx from '../../utils/clsx';
import JudgeMode from '../../judge/JudgeMode';

const MOBILE_NAV = [
  { to: '/', label: '01 · Intelligence Hub' },
  { to: '/personas', label: '02 · Persona Universe' },
  { to: '/discover', label: '03 · Discover Viewer' },
  { to: '/studio', label: '04 · Recommendation Studio' },
  { to: '/model-lab', label: '05 · Model Lab' },
  { to: '/system-pulse', label: '06 · System Pulse' },
  { to: '/story', label: '07 · Project Story' }
];

export const AppShell: React.FC = () => {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="flex min-h-screen bg-void-950">
      <Sidebar />

      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div className="w-72 bg-void-900 p-5">
            <div className="mb-6 flex items-center justify-between">
              <Logo />
              <button onClick={() => setMobileOpen(false)} className="text-slate-400">
                <X size={20} />
              </button>
            </div>
            <nav className="space-y-1">
              {MOBILE_NAV.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  end={item.to === '/'}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) => clsx('nav-item', isActive && 'nav-item-active')}
                >
                  {item.label}
                </NavLink>
              ))}
            </nav>
          </div>
          <div className="flex-1 bg-black/60" onClick={() => setMobileOpen(false)} />
        </div>
      )}

      <div className="flex min-h-screen flex-1 flex-col">
        <TopBar onOpenMobileNav={() => setMobileOpen(true)} />
        <main className="flex-1 bg-grid-fade">
          <Outlet />
        </main>
      </div>

      <JudgeMode />
    </div>
  );
};

export default AppShell;
