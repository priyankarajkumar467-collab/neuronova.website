import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  Sparkles,
  Orbit,
  UserSearch,
  Wand2,
  FlaskConical,
  Activity,
  BookOpen
} from 'lucide-react';
import clsx from '../../utils/clsx';
import { useAppData } from '../../context/AppDataContext';
import Logo from '../common/Logo';

const NAV = [
  { num: '01', to: '/', label: 'Intelligence Hub', icon: Sparkles },
  { num: '02', to: '/personas', label: 'Persona Universe', icon: Orbit },
  { num: '03', to: '/discover', label: 'Discover Viewer', icon: UserSearch },
  { num: '04', to: '/studio', label: 'Recommendation Studio', icon: Wand2 },
  { num: '05', to: '/model-lab', label: 'Model Lab', icon: FlaskConical },
  { num: '06', to: '/system-pulse', label: 'System Pulse', icon: Activity },
  { num: '07', to: '/story', label: 'Project Story', icon: BookOpen }
];

export const Sidebar: React.FC = () => {
  const { systemStatus } = useAppData();
  const overallOk = systemStatus.model === 'online';

  return (
    <aside className="hidden lg:flex h-screen w-[268px] shrink-0 flex-col border-r border-white/[0.06] bg-void-950/60 px-4 py-6">
      <div className="mb-8 px-2">
        <Logo />
      </div>

      <nav className="flex-1 space-y-1">
        {NAV.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) => clsx('nav-item', isActive && 'nav-item-active')}
          >
            <span className="font-mono text-[10px] text-slate-500">{item.num}</span>
            <item.icon size={16} strokeWidth={1.75} />
            <span className="truncate">{item.label}</span>
          </NavLink>
        ))}
      </nav>

      <div className="mt-6 rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 py-3">
        <div className="flex items-center gap-2 text-xs text-slate-400">
          <span
            className={clsx(
              'h-2 w-2 rounded-full',
              overallOk ? 'bg-signal-emerald animate-pulseGlow' : 'bg-signal-rose'
            )}
          />
          System status
        </div>
        <p className="mt-1 font-mono text-[11px] text-slate-500">
          {overallOk ? 'Model persisted & ready' : 'Awaiting model / API'}
        </p>
      </div>
    </aside>
  );
};

export default Sidebar;
