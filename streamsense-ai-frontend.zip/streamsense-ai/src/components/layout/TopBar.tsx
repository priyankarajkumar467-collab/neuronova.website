import React from 'react';
import { Play, Menu } from 'lucide-react';
import { useAppData } from '../../context/AppDataContext';
import StatusPill from '../common/StatusPill';
import DataBadge from '../common/DataBadge';

export const TopBar: React.FC<{ onOpenMobileNav: () => void }> = ({ onOpenMobileNav }) => {
  const { systemStatus, setJudgeModeOpen } = useAppData();

  return (
    <header className="sticky top-0 z-30 flex items-center justify-between gap-3 border-b border-white/[0.06] bg-void-950/70 px-4 py-3 backdrop-blur-xl sm:px-6">
      <button
        onClick={onOpenMobileNav}
        className="rounded-lg border border-white/10 p-2 text-slate-300 lg:hidden"
        aria-label="Open navigation"
      >
        <Menu size={18} />
      </button>

      <div className="hidden flex-wrap items-center gap-2 sm:flex">
        <StatusPill label="Dataset" status={systemStatus.dataset} />
        <StatusPill label="Model" status={systemStatus.model} />
        <StatusPill label="API" status={systemStatus.api} />
        <DataBadge />
      </div>

      <button className="btn-primary" onClick={() => setJudgeModeOpen(true)}>
        <Play size={15} fill="currentColor" />
        Judge Mode
      </button>
    </header>
  );
};

export default TopBar;
