import React from 'react';
import { AlertTriangle } from 'lucide-react';
import type { Persona } from '../../types';

const SMALL_CLUSTER_THRESHOLD = 0.1;
const DOMINANT_CLUSTER_THRESHOLD = 0.45;

export const ClusterBalance: React.FC<{ personas: Persona[] }> = ({ personas }) => {
  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-white/[0.06] text-[11px] uppercase tracking-wide text-slate-500">
            <th className="py-2 pr-4">Persona</th>
            <th className="py-2 pr-4">Viewers</th>
            <th className="py-2 pr-4">Audience Share</th>
            <th className="py-2">Note</th>
          </tr>
        </thead>
        <tbody>
          {personas.map((p) => {
            const small = p.audienceShare < SMALL_CLUSTER_THRESHOLD;
            const dominant = p.audienceShare > DOMINANT_CLUSTER_THRESHOLD;
            return (
              <tr key={p.clusterId} className="border-b border-white/[0.04]">
                <td className="py-2.5 pr-4 text-slate-200">{p.name}</td>
                <td className="py-2.5 pr-4 font-mono text-slate-400">{p.audienceSize.toLocaleString()}</td>
                <td className="py-2.5 pr-4">
                  <div className="flex items-center gap-2">
                    <div className="h-1.5 w-24 rounded-full bg-white/[0.06]">
                      <div
                        className="h-1.5 rounded-full bg-gradient-to-r from-signal-cyan to-signal-violet"
                        style={{ width: `${p.audienceShare * 100}%` }}
                      />
                    </div>
                    <span className="font-mono text-xs text-slate-400">{(p.audienceShare * 100).toFixed(1)}%</span>
                  </div>
                </td>
                <td className="py-2.5">
                  {(small || dominant) && (
                    <span className="inline-flex items-center gap-1 text-xs text-signal-amber">
                      <AlertTriangle size={12} />
                      {small ? 'Small cluster' : 'Dominant cluster'}
                    </span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default ClusterBalance;
