import React from 'react';
import { CheckCircle2, XCircle, Circle } from 'lucide-react';
import type { EdgeCaseResult } from '../../types';
import clsx from '../../utils/clsx';

const ICON = {
  pass: { icon: CheckCircle2, className: 'text-signal-emerald' },
  fail: { icon: XCircle, className: 'text-signal-rose' },
  not_tested: { icon: Circle, className: 'text-slate-500' }
};

export const EdgeCaseLab: React.FC<{ cases: EdgeCaseResult[] }> = ({ cases }) => (
  <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
    {cases.map((c) => {
      const meta = ICON[c.status];
      const Icon = meta.icon;
      return (
        <div
          key={c.name}
          className="flex items-center justify-between rounded-lg border border-white/[0.05] bg-white/[0.015] px-3 py-2 text-sm"
        >
          <span className="text-slate-300">{c.name}</span>
          <span className={clsx('inline-flex items-center gap-1 text-xs uppercase tracking-wide', meta.className)}>
            <Icon size={13} /> {c.status.replace('_', ' ')}
          </span>
        </div>
      );
    })}
  </div>
);

export default EdgeCaseLab;
