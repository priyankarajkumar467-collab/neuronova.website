import React from 'react';
import { CheckCircle2, AlertTriangle, XCircle, HelpCircle } from 'lucide-react';
import type { EvalStatus, EvaluationDimension } from '../../types';
import clsx from '../../utils/clsx';

const STATUS_META: Record<EvalStatus, { icon: React.ElementType; className: string; label: string }> = {
  pass: { icon: CheckCircle2, className: 'text-signal-emerald border-signal-emerald/30 bg-signal-emerald/10', label: 'Pass' },
  warning: { icon: AlertTriangle, className: 'text-signal-amber border-signal-amber/30 bg-signal-amber/10', label: 'Warning' },
  fail: { icon: XCircle, className: 'text-signal-rose border-signal-rose/30 bg-signal-rose/10', label: 'Fail' },
  not_evaluated: { icon: HelpCircle, className: 'text-slate-400 border-slate-500/30 bg-slate-500/10', label: 'Not Evaluated' }
};

export const EvaluationDimensions: React.FC<{ dimensions: EvaluationDimension[] }> = ({ dimensions }) => (
  <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
    {dimensions.map((d) => {
      const meta = STATUS_META[d.status];
      const Icon = meta.icon;
      return (
        <div key={d.name} className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-4">
          <div className="mb-2 flex items-center justify-between">
            <span className="text-sm font-medium text-slate-200">{d.name}</span>
            <span className={clsx('inline-flex items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] uppercase tracking-wide', meta.className)}>
              <Icon size={11} /> {meta.label}
            </span>
          </div>
          {d.detail && <p className="text-xs leading-relaxed text-slate-500">{d.detail}</p>}
        </div>
      );
    })}
  </div>
);

export default EvaluationDimensions;
