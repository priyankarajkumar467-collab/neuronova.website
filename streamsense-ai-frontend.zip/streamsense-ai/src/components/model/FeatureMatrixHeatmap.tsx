import React from 'react';
import type { FeatureKey, Persona } from '../../types';
import { FEATURE_LABELS } from '../../types';

const ORDER: FeatureKey[] = [
  'engagement',
  'sessionDepth',
  'frequency',
  'genreDiversity',
  'completion',
  'exploration',
  'weekendActivity'
];

function heat(value: number) {
  // interpolate between deep void and signal cyan/violet
  const alpha = 0.08 + value * 0.55;
  return `rgba(79, 216, 224, ${alpha})`;
}

export const FeatureMatrixHeatmap: React.FC<{ personas: Persona[] }> = ({ personas }) => {
  const columns = ORDER.filter((k) => personas.some((p) => typeof p.features[k] === 'number'));

  return (
    <div className="overflow-x-auto">
      <table className="w-full min-w-[560px] border-separate border-spacing-1 text-xs">
        <thead>
          <tr>
            <th className="w-32 text-left text-[10px] uppercase tracking-wide text-slate-500">Persona</th>
            {columns.map((c) => (
              <th key={c} className="px-1 text-center text-[10px] uppercase tracking-wide text-slate-500">
                {FEATURE_LABELS[c]}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {personas.map((p) => (
            <tr key={p.clusterId}>
              <td className="pr-2 text-slate-300">{p.name}</td>
              {columns.map((c) => {
                const v = p.features[c];
                return (
                  <td key={c} className="h-10 w-16 rounded-md text-center align-middle">
                    {typeof v === 'number' ? (
                      <div
                        className="flex h-9 w-full items-center justify-center rounded-md font-mono text-[11px] text-slate-100"
                        style={{ background: heat(v) }}
                      >
                        {Math.round(v * 100)}
                      </div>
                    ) : (
                      <div className="flex h-9 w-full items-center justify-center rounded-md bg-white/[0.02] text-slate-600">
                        —
                      </div>
                    )}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default FeatureMatrixHeatmap;
