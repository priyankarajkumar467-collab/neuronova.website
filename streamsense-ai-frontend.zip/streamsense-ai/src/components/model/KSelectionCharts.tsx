import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import type { KEvaluationPoint } from '../../types';

export const KSelectionCharts: React.FC<{ points: KEvaluationPoint[]; selectedK: number | null }> = ({
  points,
  selectedK
}) => {
  return (
    <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
      <div>
        <p className="mb-2 text-xs uppercase tracking-wide text-slate-500">K vs Silhouette Score</p>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={points} margin={{ left: -20 }}>
            <CartesianGrid stroke="rgba(255,255,255,0.06)" />
            <XAxis dataKey="k" tick={{ fill: '#64748b', fontSize: 11 }} />
            <YAxis tick={{ fill: '#64748b', fontSize: 11 }} domain={[0, 'dataMax + 0.05']} />
            <Tooltip contentStyle={{ background: '#0d1220', border: '1px solid rgba(255,255,255,0.08)' }} />
            {selectedK && <ReferenceLine x={selectedK} stroke="#4fd8e0" strokeDasharray="4 4" />}
            <Line type="monotone" dataKey="silhouette" stroke="#4fd8e0" strokeWidth={2} dot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
      <div>
        <p className="mb-2 text-xs uppercase tracking-wide text-slate-500">K vs Inertia (Elbow)</p>
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={points} margin={{ left: -20 }}>
            <CartesianGrid stroke="rgba(255,255,255,0.06)" />
            <XAxis dataKey="k" tick={{ fill: '#64748b', fontSize: 11 }} />
            <YAxis tick={{ fill: '#64748b', fontSize: 11 }} />
            <Tooltip contentStyle={{ background: '#0d1220', border: '1px solid rgba(255,255,255,0.08)' }} />
            {selectedK && <ReferenceLine x={selectedK} stroke="#8b7cf6" strokeDasharray="4 4" />}
            <Line type="monotone" dataKey="inertia" stroke="#8b7cf6" strokeWidth={2} dot={{ r: 3 }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

export default KSelectionCharts;
