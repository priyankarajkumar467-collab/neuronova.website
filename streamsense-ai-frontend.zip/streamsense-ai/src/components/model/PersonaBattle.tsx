import React, { useMemo, useState } from 'react';
import type { FeatureKey, Persona } from '../../types';
import { FEATURE_LABELS } from '../../types';

const ORDER: FeatureKey[] = [
  'engagement',
  'sessionDepth',
  'frequency',
  'genreDiversity',
  'completion',
  'exploration',
  'weekendActivity'
];

export const PersonaBattle: React.FC<{ personas: Persona[] }> = ({ personas }) => {
  const [aId, setAId] = useState(personas[0]?.clusterId);
  const [bId, setBId] = useState(personas[1]?.clusterId ?? personas[0]?.clusterId);

  const a = personas.find((p) => p.clusterId === aId)!;
  const b = personas.find((p) => p.clusterId === bId)!;

  const biggestDiff = useMemo(() => {
    let max = { key: ORDER[0] as FeatureKey, diff: -1 };
    ORDER.forEach((k) => {
      const av = a.features[k];
      const bv = b.features[k];
      if (typeof av === 'number' && typeof bv === 'number') {
        const diff = Math.abs(av - bv);
        if (diff > max.diff) max = { key: k, diff };
      }
    });
    return max;
  }, [a, b]);

  if (!a || !b) return null;

  return (
    <div>
      <div className="mb-5 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
        <PersonaSelect personas={personas} value={aId} onChange={setAId} />
        <span className="font-display text-sm text-slate-500">VS</span>
        <PersonaSelect personas={personas} value={bId} onChange={setBId} />
      </div>

      <div className="grid grid-cols-2 gap-4 text-sm">
        <div className="text-right">
          <p className="mb-2 font-medium text-signal-cyan">{a.name}</p>
        </div>
        <div className="text-left">
          <p className="mb-2 font-medium text-signal-violet">{b.name}</p>
        </div>
      </div>

      <div className="space-y-2">
        <MetricRow label="Audience Size" a={a.audienceSize.toLocaleString()} b={b.audienceSize.toLocaleString()} />
        {ORDER.filter((k) => typeof a.features[k] === 'number' || typeof b.features[k] === 'number').map((k) => (
          <MetricRow
            key={k}
            label={FEATURE_LABELS[k]}
            a={typeof a.features[k] === 'number' ? `${Math.round((a.features[k] as number) * 100)}%` : '—'}
            b={typeof b.features[k] === 'number' ? `${Math.round((b.features[k] as number) * 100)}%` : '—'}
            highlight={k === biggestDiff.key}
          />
        ))}
      </div>

      <div className="mt-5 rounded-xl border border-signal-amber/25 bg-signal-amber/[0.06] px-4 py-3 text-sm">
        <span className="text-slate-400">Biggest Behavioral Difference: </span>
        <span className="font-medium text-signal-amber">{FEATURE_LABELS[biggestDiff.key]}</span>
      </div>
    </div>
  );
};

const PersonaSelect: React.FC<{
  personas: Persona[];
  value: number;
  onChange: (v: number) => void;
}> = ({ personas, value, onChange }) => (
  <select
    value={value}
    onChange={(e) => onChange(Number(e.target.value))}
    className="rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-slate-100"
  >
    {personas.map((p) => (
      <option key={p.clusterId} value={p.clusterId}>
        {p.name}
      </option>
    ))}
  </select>
);

const MetricRow: React.FC<{ label: string; a: string; b: string; highlight?: boolean }> = ({
  label,
  a,
  b,
  highlight
}) => (
  <div
    className={
      highlight
        ? 'grid grid-cols-[1fr_auto_1fr] items-center gap-3 rounded-lg bg-signal-amber/[0.06] px-2 py-1.5'
        : 'grid grid-cols-[1fr_auto_1fr] items-center gap-3 px-2 py-1.5'
    }
  >
    <span className="text-right font-mono text-slate-200">{a}</span>
    <span className="text-center text-[10px] uppercase tracking-wide text-slate-500">{label}</span>
    <span className="text-left font-mono text-slate-200">{b}</span>
  </div>
);

export default PersonaBattle;
