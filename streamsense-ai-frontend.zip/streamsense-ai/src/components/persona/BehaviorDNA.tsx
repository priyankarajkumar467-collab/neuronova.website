import React from 'react';
import type { BehaviorFeatureVector, FeatureKey } from '../../types';
import { FEATURE_LABELS } from '../../types';

const ORDER: FeatureKey[] = [
  'engagement',
  'sessionDepth',
  'frequency',
  'genreDiversity',
  'completion',
  'exploration',
  'weekendActivity'
];

const BAR_SEGMENTS = 10;

export const BehaviorDNA: React.FC<{ features: BehaviorFeatureVector; compact?: boolean }> = ({
  features,
  compact
}) => {
  const available = ORDER.filter((k) => typeof features[k] === 'number');

  if (available.length === 0) {
    return <p className="text-sm text-slate-500">No behavioral dimensions available for this persona yet.</p>;
  }

  const signature = available
    .map((k) => `${FEATURE_LABELS[k][0]}${Math.round((features[k] as number) * 10)}`)
    .join(' • ');

  return (
    <div>
      <div className="space-y-2.5">
        {available.map((key) => {
          const value = features[key] as number;
          const filled = Math.round(value * BAR_SEGMENTS);
          return (
            <div key={key} className="flex items-center gap-3">
              <span className="w-[120px] shrink-0 font-mono text-[10px] uppercase tracking-wider text-slate-400">
                {FEATURE_LABELS[key]}
              </span>
              <div className="flex flex-1 gap-[3px]">
                {Array.from({ length: BAR_SEGMENTS }).map((_, i) => (
                  <span
                    key={i}
                    className="h-2.5 flex-1 rounded-sm"
                    style={{
                      background:
                        i < filled
                          ? 'linear-gradient(90deg, #4fd8e0, #8b7cf6)'
                          : 'rgba(255,255,255,0.06)'
                    }}
                  />
                ))}
              </div>
              <span className="w-9 shrink-0 text-right font-mono text-[11px] text-slate-400">
                {Math.round(value * 100)}%
              </span>
            </div>
          );
        })}
      </div>

      {!compact && (
        <p className="mt-4 font-mono text-xs tracking-wide text-signal-cyan/80">{signature}</p>
      )}
      <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
        This fingerprint is a direct visualization of normalized behavioral features from the trained
        model — it is not a separate machine learning model.
      </p>
    </div>
  );
};

export default BehaviorDNA;
