import React from 'react';
import type { Persona } from '../../types';
import clsx from '../../utils/clsx';

const PALETTE = ['#4fd8e0', '#8b7cf6', '#f5b95e', '#f47b9c', '#4fe0a8', '#7dd3fc', '#c4b5fd'];

// Deterministic layout so orbs don't jump around on re-render.
const POSITIONS = [
  { top: '18%', left: '20%' },
  { top: '55%', left: '12%' },
  { top: '30%', left: '55%' },
  { top: '68%', left: '58%' },
  { top: '15%', left: '78%' },
  { top: '75%', left: '82%' },
  { top: '45%', left: '85%' }
];

interface Props {
  personas: Persona[];
  selectedId: number | null;
  onSelect: (clusterId: number) => void;
}

export const PersonaOrbField: React.FC<Props> = ({ personas, selectedId, onSelect }) => {
  const maxSize = Math.max(...personas.map((p) => p.audienceSize), 1);

  return (
    <div className="relative h-[420px] w-full overflow-hidden rounded-2xl border border-white/[0.06] bg-void-900/60">
      {/* faint connective lines */}
      <svg className="absolute inset-0 h-full w-full opacity-30" xmlns="http://www.w3.org/2000/svg">
        {personas.map((_, i) =>
          personas.slice(i + 1).map((_, j) => {
            const a = POSITIONS[i % POSITIONS.length];
            const b = POSITIONS[(i + j + 1) % POSITIONS.length];
            return (
              <line
                key={`${i}-${j}`}
                x1={a.left}
                y1={a.top}
                x2={b.left}
                y2={b.top}
                stroke="rgba(148,163,184,0.12)"
                strokeWidth={1}
              />
            );
          })
        )}
      </svg>

      {personas.map((persona, idx) => {
        const pos = POSITIONS[idx % POSITIONS.length];
        const size = 64 + (persona.audienceSize / maxSize) * 92;
        const color = PALETTE[idx % PALETTE.length];
        const active = selectedId === persona.clusterId;
        return (
          <button
            key={persona.clusterId}
            onClick={() => onSelect(persona.clusterId)}
            className={clsx(
              'group absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center justify-center rounded-full border transition-all duration-300 animate-floatSlow',
              active ? 'z-10 scale-105 border-white/40' : 'border-white/10 hover:border-white/25'
            )}
            style={{
              top: pos.top,
              left: pos.left,
              width: size,
              height: size,
              background: `radial-gradient(circle at 35% 30%, ${color}33, ${color}0d 70%)`,
              boxShadow: active ? `0 0 40px -6px ${color}88` : `0 0 20px -8px ${color}55`,
              animationDelay: `${idx * 0.4}s`
            }}
          >
            <span className="px-2 text-center text-[11px] font-medium leading-tight text-slate-100">
              {persona.name}
            </span>
            <span className="mt-0.5 font-mono text-[10px] text-slate-400">
              {(persona.audienceShare * 100).toFixed(1)}%
            </span>
          </button>
        );
      })}
    </div>
  );
};

export default PersonaOrbField;
