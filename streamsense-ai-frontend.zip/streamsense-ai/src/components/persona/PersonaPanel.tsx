import React from 'react';
import { X, Users, PieChart, Tag } from 'lucide-react';
import type { Persona } from '../../types';
import { FEATURE_LABELS } from '../../types';
import BehaviorDNA from './BehaviorDNA';
import { DEMO_AVERAGE_VIEWER_FEATURES } from '../../data/demoData';

export const PersonaPanel: React.FC<{ persona: Persona; onClose: () => void }> = ({ persona, onClose }) => {
  const diffs = (Object.keys(persona.features) as (keyof typeof persona.features)[])
    .filter((k) => typeof persona.features[k] === 'number')
    .map((k) => {
      const value = persona.features[k] as number;
      const baseline = (DEMO_AVERAGE_VIEWER_FEATURES as any)[k] as number | undefined;
      if (baseline === undefined) return null;
      const pct = ((value - baseline) / baseline) * 100;
      return { key: k, pct };
    })
    .filter(Boolean) as { key: keyof typeof persona.features; pct: number }[];

  return (
    <div className="glass-panel flex h-full flex-col p-5">
      <div className="mb-4 flex items-start justify-between">
        <div>
          {persona.isDemo && <span className="badge-demo mb-2">Demo Persona</span>}
          <h3 className="font-display text-xl font-semibold text-slate-50">{persona.name}</h3>
          <p className="font-mono text-xs text-slate-500">Cluster ID {persona.clusterId}</p>
        </div>
        <button onClick={onClose} className="rounded-lg p-1.5 text-slate-400 hover:bg-white/5">
          <X size={18} />
        </button>
      </div>

      <div className="mb-5 grid grid-cols-2 gap-3">
        <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3">
          <div className="flex items-center gap-1.5 text-slate-500">
            <Users size={13} />
            <span className="text-[10px] uppercase tracking-wider">Audience Size</span>
          </div>
          <p className="mt-1 font-display text-lg font-semibold text-slate-50">
            {persona.audienceSize.toLocaleString()}
          </p>
        </div>
        <div className="rounded-xl border border-white/[0.06] bg-white/[0.02] p-3">
          <div className="flex items-center gap-1.5 text-slate-500">
            <PieChart size={13} />
            <span className="text-[10px] uppercase tracking-wider">Audience Share</span>
          </div>
          <p className="mt-1 font-display text-lg font-semibold text-slate-50">
            {(persona.audienceShare * 100).toFixed(1)}%
          </p>
        </div>
      </div>

      {persona.topGenre && (
        <div className="mb-5 flex items-center gap-2 rounded-xl border border-white/[0.06] bg-white/[0.02] px-3 py-2">
          <Tag size={13} className="text-signal-violet" />
          <span className="text-xs text-slate-400">Top Genre</span>
          <span className="ml-auto text-sm font-medium text-slate-100">{persona.topGenre}</span>
        </div>
      )}

      <p className="mb-2 kicker">Behavior DNA</p>
      <BehaviorDNA features={persona.features} />

      {persona.narrative && (
        <>
          <p className="mb-2 mt-6 kicker">Who Are They?</p>
          <p className="text-sm leading-relaxed text-slate-300">{persona.narrative}</p>
        </>
      )}

      {diffs.length > 0 && (
        <>
          <p className="mb-2 mt-6 kicker">How They Differ From the Average Viewer</p>
          <div className="space-y-1.5">
            {diffs.map((d) => (
              <div key={d.key} className="flex items-center justify-between text-xs">
                <span className="text-slate-400">{FEATURE_LABELS[d.key]}</span>
                <span className={d.pct >= 0 ? 'text-signal-emerald' : 'text-signal-rose'}>
                  {d.pct >= 0 ? '↑' : '↓'} {Math.abs(d.pct).toFixed(0)}%
                </span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default PersonaPanel;
