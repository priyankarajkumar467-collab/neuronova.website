import React from 'react';
import type { BehaviorFeatureVector } from '../../types';

const PALETTE = ['#4fd8e0', '#8b7cf6', '#f5b95e', '#f47b9c', '#4fe0a8'];

/**
 * Purely a visual representation of normalized behavioral values —
 * concentric rings whose radius/opacity map to feature intensity.
 * Not a separate model, not a "confidence" indicator.
 */
export const DigitalTwin: React.FC<{ features: BehaviorFeatureVector; accent?: string }> = ({
  features,
  accent = PALETTE[0]
}) => {
  const values = Object.values(features).filter((v): v is number => typeof v === 'number');
  const rings = values.length > 0 ? values : [0.4, 0.5, 0.45];

  return (
    <div className="relative flex h-64 w-full items-center justify-center">
      <svg viewBox="0 0 300 300" className="h-64 w-64">
        <defs>
          <radialGradient id="twin-core" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor={accent} stopOpacity="0.9" />
            <stop offset="100%" stopColor={accent} stopOpacity="0" />
          </radialGradient>
        </defs>
        <circle cx="150" cy="150" r="26" fill="url(#twin-core)" className="animate-pulseGlow" />
        {rings.map((v, i) => {
          const radius = 40 + i * 22 + v * 26;
          return (
            <circle
              key={i}
              cx="150"
              cy="150"
              r={radius}
              fill="none"
              stroke={accent}
              strokeOpacity={Math.max(0.12, 0.55 - i * 0.06)}
              strokeWidth={1.4}
              strokeDasharray={`${4 + v * 10} ${6 - v * 2}`}
            />
          );
        })}
        <circle cx="150" cy="150" r="4" fill="#fff" />
      </svg>
    </div>
  );
};

export default DigitalTwin;
