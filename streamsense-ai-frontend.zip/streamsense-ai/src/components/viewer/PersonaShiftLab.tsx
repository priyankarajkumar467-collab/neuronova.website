import React, { useState } from 'react';
import { RefreshCw, ArrowDown } from 'lucide-react';
import type { RecommendRequest, RecommendResponse } from '../../types';
import { simulateRecommend } from '../../utils/simulate';
import { isLiveMode, postRecommend } from '../../api/client';

interface Props {
  baseInput: RecommendRequest;
  baseResult: RecommendResponse;
}

export const PersonaShiftLab: React.FC<Props> = ({ baseInput, baseResult }) => {
  const [watchTime, setWatchTime] = useState(baseInput.watch_time_hours);
  const [sessionMins, setSessionMins] = useState(baseInput.avg_session_mins);
  const [result, setResult] = useState<RecommendResponse | null>(null);
  const [loading, setLoading] = useState(false);

  const reEvaluate = async () => {
    setLoading(true);
    const nextInput: RecommendRequest = {
      ...baseInput,
      watch_time_hours: watchTime,
      avg_session_mins: sessionMins
    };
    try {
      const res = isLiveMode() ? await postRecommend(nextInput) : simulateRecommend(nextInput);
      setResult(res);
    } finally {
      setLoading(false);
    }
  };

  const shifted = result && result.segment_id !== baseResult.segment_id;

  return (
    <div>
      <p className="mb-5 text-sm text-slate-400">
        Adjust this viewer's behavioral inputs and re-evaluate against the same pipeline.
      </p>

      <div className="space-y-5">
        <SliderRow
          label="Watch Time (hours)"
          value={watchTime}
          min={0}
          max={80}
          step={0.5}
          onChange={setWatchTime}
        />
        <SliderRow
          label="Avg Session Duration (mins)"
          value={sessionMins}
          min={5}
          max={180}
          step={1}
          onChange={setSessionMins}
        />
      </div>

      <button onClick={reEvaluate} disabled={loading} className="btn-primary mt-6 w-full sm:w-auto">
        <RefreshCw size={15} className={loading ? 'animate-spin' : ''} />
        Re-Evaluate Persona
      </button>

      {result && (
        <div className="mt-6 rounded-xl border border-white/[0.06] bg-white/[0.02] p-4">
          <p
            className={
              shifted
                ? 'mb-3 text-sm font-semibold text-signal-amber'
                : 'mb-3 text-sm font-semibold text-signal-emerald'
            }
          >
            {shifted ? 'Persona Shift Detected' : 'Persona Stable'}
          </p>

          {shifted ? (
            <div className="mb-4 flex flex-col items-center gap-1 text-center">
              <span className="rounded-lg bg-white/[0.04] px-3 py-1.5 text-sm text-slate-300">
                {baseResult.segment_name}
              </span>
              <ArrowDown size={16} className="text-slate-500" />
              <span className="rounded-lg border border-signal-amber/30 bg-signal-amber/10 px-3 py-1.5 text-sm text-signal-amber">
                {result.segment_name}
              </span>
            </div>
          ) : (
            <p className="mb-4 text-sm text-slate-400">
              Segment remains{' '}
              <span className="font-medium text-slate-200">{result.segment_name}</span> after the change.
            </p>
          )}

          <p className="mb-2 text-xs uppercase tracking-wide text-slate-500">What Changed?</p>
          <div className="space-y-1 font-mono text-xs text-slate-400">
            <ChangeRow
              label="Watch time"
              before={`${baseInput.watch_time_hours}h`}
              after={`${watchTime}h`}
              changed={watchTime !== baseInput.watch_time_hours}
            />
            <ChangeRow
              label="Session duration"
              before={`${baseInput.avg_session_mins}m`}
              after={`${sessionMins}m`}
              changed={sessionMins !== baseInput.avg_session_mins}
            />
          </div>
          <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
            Only the inputs above were changed. Any shift in assigned persona is the pipeline's own
            recalculation — StreamSense AI does not fabricate a reason for the model's decision.
          </p>
        </div>
      )}
    </div>
  );
};

const SliderRow: React.FC<{
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
}> = ({ label, value, min, max, step, onChange }) => (
  <div>
    <div className="mb-1.5 flex items-center justify-between text-xs">
      <span className="text-slate-400">{label}</span>
      <span className="font-mono text-slate-200">{value}</span>
    </div>
    <input
      type="range"
      min={min}
      max={max}
      step={step}
      value={value}
      onChange={(e) => onChange(Number(e.target.value))}
      className="h-1.5 w-full cursor-pointer appearance-none rounded-full bg-white/10 accent-signal-cyan"
    />
  </div>
);

const ChangeRow: React.FC<{ label: string; before: string; after: string; changed: boolean }> = ({
  label,
  before,
  after,
  changed
}) => (
  <div className="flex items-center justify-between">
    <span>{label}</span>
    <span className={changed ? 'text-signal-amber' : 'text-slate-500'}>
      {before} → {after} {changed ? (Number(after) > Number(before) ? '↑' : '↓') : ''}
    </span>
  </div>
);

export default PersonaShiftLab;
