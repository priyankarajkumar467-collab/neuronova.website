import React from 'react';
import type { CompassWeights } from '../../types';

const DIRECTIONS: { key: keyof CompassWeights; label: string; angle: number }[] = [
  { key: 'familiar', label: 'Familiar', angle: 270 },
  { key: 'discover', label: 'Discover', angle: 0 },
  { key: 'trending', label: 'Trending', angle: 90 },
  { key: 'quickWatch', label: 'Quick Watch', angle: 180 }
];

export const PersonalizationCompass: React.FC<{ weights: CompassWeights }> = ({ weights }) => {
  const size = 220;
  const center = size / 2;
  const maxR = 84;

  const points = DIRECTIONS.map((d) => {
    const w = weights[d.key];
    const r = 24 + w * maxR;
    const rad = (d.angle * Math.PI) / 180;
    return {
      ...d,
      w,
      x: center + r * Math.cos(rad),
      y: center + r * Math.sin(rad)
    };
  });

  const polygon = points.map((p) => `${p.x},${p.y}`).join(' ');

  return (
    <div className="flex flex-col items-center">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {[0.25, 0.5, 0.75, 1].map((f) => (
          <circle
            key={f}
            cx={center}
            cy={center}
            r={24 + f * maxR}
            fill="none"
            stroke="rgba(255,255,255,0.07)"
          />
        ))}
        <line x1={center} y1={0} x2={center} y2={size} stroke="rgba(255,255,255,0.06)" />
        <line x1={0} y1={center} x2={size} y2={center} stroke="rgba(255,255,255,0.06)" />
        <polygon points={polygon} fill="url(#compass-fill)" stroke="#4fd8e0" strokeWidth={1.6} />
        <defs>
          <linearGradient id="compass-fill" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#4fd8e0" stopOpacity="0.35" />
            <stop offset="100%" stopColor="#8b7cf6" stopOpacity="0.2" />
          </linearGradient>
        </defs>
        {points.map((p) => (
          <circle key={p.key} cx={p.x} cy={p.y} r={3.5} fill="#fff" />
        ))}
      </svg>
      <div className="mt-2 grid w-full grid-cols-2 gap-x-6 gap-y-1 text-center font-mono text-[10px] uppercase tracking-wider text-slate-400">
        {points.map((p) => (
          <div key={p.key} className="flex items-center justify-between">
            <span>{p.label}</span>
            <span className="text-slate-200">{Math.round(p.w * 100)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PersonalizationCompass;
