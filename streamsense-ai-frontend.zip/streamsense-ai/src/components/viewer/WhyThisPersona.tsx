import React from 'react';
import { ArrowUpRight, ArrowRight } from 'lucide-react';
import type { BehaviorFeatureVector, Persona } from '../../types';
import { FEATURE_LABELS } from '../../types';
import { distanceLabel } from '../../utils/simulate';

interface Props {
  features: BehaviorFeatureVector;
  persona: Persona;
  distanceToCentroid: number;
  isSimulated: boolean;
}

export const WhyThisPersona: React.FC<Props> = ({ features, persona, distanceToCentroid, isSimulated }) => {
  const ranked = (Object.keys(features) as (keyof BehaviorFeatureVector)[])
    .filter((k) => typeof features[k] === 'number')
    .map((k) => ({ key: k, value: features[k] as number }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 3);

  return (
    <div>
      <p className="mb-3 text-sm text-slate-400">
        These behavioral signals most strongly matched the assigned community:
      </p>
      <div className="mb-5 space-y-2">
        {ranked.map((r) => (
          <div key={r.key} className="flex items-center gap-2 text-sm text-slate-200">
            <ArrowUpRight size={14} className="text-signal-cyan" />
            <span className="text-slate-400">{FEATURE_LABELS[r.key]}</span>
            <span className="ml-auto font-mono text-xs text-slate-300">{Math.round(r.value * 100)}%</span>
          </div>
        ))}
      </div>

      <div className="mb-5 flex items-center gap-2 rounded-xl border border-signal-cyan/20 bg-signal-cyan/[0.06] px-4 py-3">
        <span className="text-xs text-slate-400">Matched Behavioral Community</span>
        <ArrowRight size={13} className="text-signal-cyan" />
        <span className="font-medium text-slate-100">{persona.name}</span>
      </div>

      <div className="flex items-center justify-between rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3">
        <div>
          <p className="text-[11px] uppercase tracking-wide text-slate-500">Behavioral Distance</p>
          <p className="font-mono text-lg text-slate-100">{distanceToCentroid.toFixed(3)}</p>
        </div>
        <span className="badge-live !border-signal-violet/30 !bg-signal-violet/10 !text-signal-violet">
          {distanceLabel(distanceToCentroid)}
        </span>
      </div>
      <p className="mt-2 text-[11px] leading-relaxed text-slate-500">
        Distance to centroid reflects how close this viewer's behavior sits to the persona's center — it is
        not a confidence probability.
        {isSimulated && ' Values here are simulated locally in Demo Mode, not produced by a trained model.'}
      </p>
    </div>
  );
};

export default WhyThisPersona;
