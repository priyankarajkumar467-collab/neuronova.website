import React, { createContext, useContext, useMemo, useState, useCallback } from 'react';
import {
  DEMO_EDGE_CASES,
  DEMO_EVALUATION,
  DEMO_K_EVALUATION,
  DEMO_MODEL_INFO,
  DEMO_PERSONAS,
  DEMO_RECOMMENDATIONS_BY_CLUSTER,
  DEMO_SYSTEM_STATUS,
  DEMO_VIEWERS
} from '../data/demoData';
import { isLiveMode } from '../api/client';
import type {
  EvaluationReport,
  KEvaluationPoint,
  ModelInfo,
  Persona,
  RecommendationItem,
  SystemStatus,
  Viewer
} from '../types';

interface AppDataShape {
  source: 'demo' | 'live';
  systemStatus: SystemStatus;
  modelInfo: ModelInfo;
  kEvaluation: KEvaluationPoint[];
  personas: Persona[];
  viewers: Viewer[];
  evaluation: EvaluationReport;
  recommendationsByCluster: Record<number, RecommendationItem[]>;
  judgeModeOpen: boolean;
  setJudgeModeOpen: (open: boolean) => void;
}

const AppDataContext = createContext<AppDataShape | null>(null);

export const AppDataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [judgeModeOpen, setJudgeModeOpen] = useState(false);
  const live = isLiveMode();

  // In DEMO MODE we simply serve the centralized mock dataset.
  // In LIVE MODE, this is the single place where real fetches would be
  // wired in (e.g. via React Query / useEffect) to replace the demo values below.
  const value = useMemo<AppDataShape>(
    () => ({
      source: live ? 'live' : 'demo',
      systemStatus: DEMO_SYSTEM_STATUS,
      modelInfo: DEMO_MODEL_INFO,
      kEvaluation: DEMO_K_EVALUATION,
      personas: DEMO_PERSONAS,
      viewers: DEMO_VIEWERS,
      evaluation: DEMO_EVALUATION,
      recommendationsByCluster: DEMO_RECOMMENDATIONS_BY_CLUSTER,
      judgeModeOpen,
      setJudgeModeOpen
    }),
    [live, judgeModeOpen]
  );

  return <AppDataContext.Provider value={value}>{children}</AppDataContext.Provider>;
};

export function useAppData() {
  const ctx = useContext(AppDataContext);
  if (!ctx) throw new Error('useAppData must be used within AppDataProvider');
  return ctx;
}

export { DEMO_EDGE_CASES };
