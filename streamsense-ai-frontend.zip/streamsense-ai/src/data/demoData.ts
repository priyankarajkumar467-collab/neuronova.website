// ============================================================
// StreamSense AI — CENTRALIZED DEMO DATA
// ------------------------------------------------------------
// Every mock value used by the frontend lives in this single file.
// Nothing here should be scattered into individual components.
//
// When the real FastAPI backend (Trainer / API / Evaluator) is
// connected, `src/api/client.ts` will fetch real data instead of
// importing from here, and every UI surface that renders these
// values must show a "Demo Data" badge (see DataSource type).
//
// DO NOT treat these numbers as real ML results. They exist only
// to make the interface presentable before a backend is attached.
// ============================================================

import type {
  EdgeCaseResult,
  EvaluationDimension,
  EvaluationReport,
  KEvaluationPoint,
  ModelInfo,
  Persona,
  RecommendationItem,
  SystemStatus,
  Viewer
} from '../types';

export const DEMO_SYSTEM_STATUS: SystemStatus = {
  dataset: 'online',
  model: 'online',
  api: 'offline', // honestly reflects: no backend attached yet in this build
  evaluator: 'unknown',
  source: 'demo'
};

export const DEMO_MODEL_INFO: ModelInfo = {
  algorithm: 'KMeans',
  preprocessing: 'StandardScaler',
  randomSeed: 42,
  selectedK: 5,
  silhouetteScore: 0.41,
  inertia: 1189.7,
  available: true
};

export const DEMO_K_EVALUATION: KEvaluationPoint[] = [
  { k: 2, silhouette: 0.29, inertia: 3120.4 },
  { k: 3, silhouette: 0.33, inertia: 2340.1 },
  { k: 4, silhouette: 0.37, inertia: 1780.6 },
  { k: 5, silhouette: 0.41, inertia: 1189.7 },
  { k: 6, silhouette: 0.36, inertia: 1010.2 },
  { k: 7, silhouette: 0.32, inertia: 902.5 },
  { k: 8, silhouette: 0.28, inertia: 820.9 }
];

export const DEMO_PERSONAS: Persona[] = [
  {
    clusterId: 0,
    name: 'Binge Enthusiasts',
    audienceSize: 2140,
    audienceShare: 0.284,
    topGenre: 'Drama',
    features: {
      engagement: 0.92,
      sessionDepth: 0.88,
      frequency: 0.81,
      genreDiversity: 0.44,
      completion: 0.86,
      exploration: 0.31,
      weekendActivity: 0.74
    },
    narrative:
      'These viewers demonstrate high engagement and longer-than-average sessions, with concentrated preferences for a smaller number of genres.',
    isDemo: true
  },
  {
    clusterId: 1,
    name: 'Quick-Session Viewers',
    audienceSize: 1385,
    audienceShare: 0.184,
    topGenre: 'Comedy',
    features: {
      engagement: 0.42,
      sessionDepth: 0.21,
      frequency: 0.58,
      genreDiversity: 0.52,
      completion: 0.38,
      exploration: 0.4,
      weekendActivity: 0.35
    },
    narrative:
      'This group watches frequently but in short bursts, favoring lighter content with lower per-session completion rates.',
    isDemo: true
  },
  {
    clusterId: 2,
    name: 'Genre Loyalists',
    audienceSize: 1620,
    audienceShare: 0.215,
    topGenre: 'Action',
    features: {
      engagement: 0.68,
      sessionDepth: 0.61,
      frequency: 0.55,
      genreDiversity: 0.18,
      completion: 0.71,
      exploration: 0.14,
      weekendActivity: 0.5
    },
    narrative:
      'A tightly focused audience that returns consistently to a narrow set of genres, with high completion once they start watching.',
    isDemo: true
  },
  {
    clusterId: 3,
    name: 'Content Explorers',
    audienceSize: 1204,
    audienceShare: 0.16,
    topGenre: 'Documentary',
    features: {
      engagement: 0.6,
      sessionDepth: 0.5,
      frequency: 0.46,
      genreDiversity: 0.9,
      completion: 0.55,
      exploration: 0.88,
      weekendActivity: 0.44
    },
    narrative:
      'Explorers sample broadly across genres with moderate engagement per title, prioritizing variety over depth.',
    isDemo: true
  },
  {
    clusterId: 4,
    name: 'Occasional Viewers',
    audienceSize: 1191,
    audienceShare: 0.158,
    topGenre: 'Family',
    features: {
      engagement: 0.24,
      sessionDepth: 0.28,
      frequency: 0.19,
      genreDiversity: 0.35,
      completion: 0.4,
      exploration: 0.22,
      weekendActivity: 0.61
    },
    narrative:
      'Low overall activity concentrated on weekends, with infrequent but complete viewing sessions.',
    isDemo: true
  }
];

// Average-viewer baseline used for "how they differ from the average viewer"
export const DEMO_AVERAGE_VIEWER_FEATURES = {
  engagement: 0.57,
  sessionDepth: 0.5,
  frequency: 0.52,
  genreDiversity: 0.48,
  completion: 0.58,
  exploration: 0.39,
  weekendActivity: 0.53
};

// A small representative population for the Audience Universe scatter plot.
// projection.isPCA = false because no PCA has actually been computed for this demo set —
// coordinates are a simple feature-based (watch time vs session length) plot, honestly labeled.
function seededViewers(): Viewer[] {
  const genrePool = ['Action', 'Drama', 'Comedy', 'Thriller', 'Documentary', 'Family', 'Sci-Fi'];
  const viewers: Viewer[] = [];
  let seed = 7;
  const rand = () => {
    seed = (seed * 9301 + 49297) % 233280;
    return seed / 233280;
  };
  for (let i = 0; i < 140; i++) {
    const cluster = Math.floor(rand() * DEMO_PERSONAS.length);
    const persona = DEMO_PERSONAS[cluster];
    const watch = Math.max(0.5, (persona.features.engagement ?? 0.5) * 60 + (rand() - 0.5) * 14);
    const session = Math.max(5, (persona.features.sessionDepth ?? 0.5) * 110 + (rand() - 0.5) * 20);
    viewers.push({
      userId: `USR-${(1000 + i).toString()}`,
      watchTimeHours: Math.round(watch * 10) / 10,
      avgSessionMins: Math.round(session),
      topGenres: [genrePool[Math.floor(rand() * genrePool.length)]],
      clusterId: cluster,
      projection: {
        x: Math.round((watch + (rand() - 0.5) * 8) * 10) / 10,
        y: Math.round((session + (rand() - 0.5) * 10) * 10) / 10,
        isPCA: false
      }
    });
  }
  return viewers;
}

export const DEMO_VIEWERS: Viewer[] = seededViewers();

export const DEMO_RECOMMENDATIONS_BY_CLUSTER: Record<number, RecommendationItem[]> = {
  0: [
    { title: 'Midnight Ledger', genre: 'Drama', reason: 'Matches high completion + Drama affinity' },
    { title: 'The Long Season', genre: 'Drama', reason: 'Long-form content fits high session depth' },
    { title: 'Ashen Coast', genre: 'Drama', reason: 'Consistent genre concentration signal' }
  ],
  1: [
    { title: 'Quick Cuts', genre: 'Comedy', reason: 'Short runtime fits low session depth' },
    { title: 'Laugh Track', genre: 'Comedy', reason: 'High-frequency, low-commitment viewing pattern' },
    { title: 'Snack Sized', genre: 'Comedy', reason: 'Episodic structure matches short sessions' }
  ],
  2: [
    { title: 'Iron Perimeter', genre: 'Action', reason: 'Strong single-genre loyalty signal' },
    { title: 'Redline', genre: 'Action', reason: 'High completion rate on similar titles' },
    { title: 'Vantage Point', genre: 'Action', reason: 'Low exploration score favors familiar genre' }
  ],
  3: [
    { title: 'Field Notes', genre: 'Documentary', reason: 'High exploration score favors new categories' },
    { title: 'Signal & Noise', genre: 'Sci-Fi', reason: 'Genre-diversity score supports cross-genre picks' },
    { title: 'Wide Frame', genre: 'Documentary', reason: 'Consistent with broad sampling behavior' }
  ],
  4: [
    { title: 'Weekend Matinee', genre: 'Family', reason: 'Weekend-activity concentration signal' },
    { title: 'Sunday Reel', genre: 'Family', reason: 'Low frequency, high per-session completion' },
    { title: 'Home Screen', genre: 'Family', reason: 'Matches occasional but complete viewing pattern' }
  ]
};

export const DEMO_EDGE_CASES: EdgeCaseResult[] = [
  { name: 'Unknown genre', status: 'not_tested' },
  { name: 'Empty top_genres', status: 'not_tested' },
  { name: 'Zero watch time', status: 'not_tested' },
  { name: 'Very large watch time', status: 'not_tested' },
  { name: 'Missing required field', status: 'not_tested' },
  { name: 'String instead of number', status: 'not_tested' },
  { name: 'Negative values', status: 'not_tested' },
  { name: 'Repeated requests', status: 'not_tested' },
  { name: 'Model not yet loaded', status: 'not_tested' }
];

export const DEMO_EVALUATION: EvaluationReport = {
  available: true,
  generatedAt: '2026-09-15T04:12:00Z',
  dimensions: [
    { name: 'Clustering Quality', status: 'pass', detail: 'Silhouette 0.41 across selected K=5' },
    { name: 'Cluster Balance', status: 'warning', detail: 'Smallest cluster holds 15.8% of viewers' },
    { name: 'Stability', status: 'pass', detail: 'Consistent assignments across 5 re-runs with fixed seed' },
    { name: 'API Correctness', status: 'not_evaluated', detail: 'Backend not connected in this build' },
    { name: 'Robustness', status: 'not_evaluated', detail: 'Edge-case suite requires a live API' },
    { name: 'Reproducibility', status: 'pass', detail: 'Fixed random seed (42) documented and persisted' }
  ],
  edgeCases: DEMO_EDGE_CASES
};

export const DEMO_PROFILE_FOR_JUDGE_MODE = {
  user_id: 'USR-DEMO-01',
  watch_time_hours: 34.5,
  avg_session_mins: 92,
  top_genres: ['Action', 'Thriller']
};
