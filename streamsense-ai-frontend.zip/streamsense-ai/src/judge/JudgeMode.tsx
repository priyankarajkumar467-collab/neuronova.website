import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { X, ArrowRight, ArrowLeft, Play } from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import { DEMO_PROFILE_FOR_JUDGE_MODE } from '../data/demoData';

interface Step {
  title: string;
  description: string;
  route?: string;
  quote?: string;
}

const STEPS: Step[] = [
  {
    title: 'The Problem',
    description: 'A single recommendation strategy cannot serve every viewer effectively.',
    quote: '“Your audience is not one audience.”',
    route: '/'
  },
  {
    title: 'The Discovery',
    description: 'Unsupervised clustering finds behavioral communities inside raw viewing activity.',
    route: '/personas'
  },
  {
    title: 'The Personas',
    description: 'Behavior DNA translates cluster math into a readable fingerprint per persona.',
    route: '/personas'
  },
  {
    title: 'The Viewer',
    description: `Load a demo profile (${DEMO_PROFILE_FOR_JUDGE_MODE.user_id}) and run it through the live pipeline.`,
    route: '/discover'
  },
  {
    title: 'The Result',
    description: 'The pipeline assigns a behavioral segment and builds a Viewer Digital Twin.',
    route: '/discover'
  },
  {
    title: 'The Explanation',
    description: 'Behavioral Fingerprint + "Why This Persona?" make the assignment transparent, not a black box.',
    route: '/discover'
  },
  {
    title: 'The Action',
    description: 'Recommendation Studio turns the persona into explainable, rule-based personalization.',
    route: '/studio'
  },
  {
    title: 'The Evidence',
    description: 'Model Lab shows K-selection evidence, cluster balance, and independent evaluation results.',
    route: '/model-lab'
  },
  {
    title: 'The Engineering',
    description: 'System Pulse shows the containerized Trainer → API → Evaluator architecture.',
    route: '/system-pulse'
  },
  {
    title: 'StreamSense AI',
    description: 'Behavior → Persona → Personalization.',
    route: '/story'
  }
];

export const JudgeMode: React.FC = () => {
  const { judgeModeOpen, setJudgeModeOpen } = useAppData();
  const [idx, setIdx] = useState(0);
  const navigate = useNavigate();

  if (!judgeModeOpen) return null;

  const step = STEPS[idx];

  const go = (next: number) => {
    const clamped = Math.max(0, Math.min(STEPS.length - 1, next));
    setIdx(clamped);
    if (STEPS[clamped].route) navigate(STEPS[clamped].route!);
  };

  const close = () => {
    setJudgeModeOpen(false);
    setIdx(0);
  };

  return (
    <div className="fixed inset-x-0 bottom-0 z-40 flex justify-center p-4 sm:p-6">
      <div className="glass-panel w-full max-w-2xl p-5 shadow-glow-violet">
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Play size={14} className="text-signal-cyan" fill="currentColor" />
            <span className="kicker">Judge Mode · Step {idx + 1} / {STEPS.length}</span>
          </div>
          <button onClick={close} className="text-slate-400 hover:text-slate-200">
            <X size={18} />
          </button>
        </div>

        <h3 className="font-display text-lg font-semibold text-slate-50">{step.title}</h3>
        {step.quote && <p className="mt-1 text-sm italic text-signal-cyan/80">{step.quote}</p>}
        <p className="mt-2 text-sm text-slate-400">{step.description}</p>

        <div className="mt-4 flex items-center justify-between">
          <button
            onClick={() => go(idx - 1)}
            disabled={idx === 0}
            className="btn-secondary disabled:opacity-30"
          >
            <ArrowLeft size={14} /> Back
          </button>
          <div className="flex gap-1">
            {STEPS.map((_, i) => (
              <span
                key={i}
                className={
                  i === idx
                    ? 'h-1.5 w-4 rounded-full bg-signal-cyan'
                    : 'h-1.5 w-1.5 rounded-full bg-white/15'
                }
              />
            ))}
          </div>
          {idx < STEPS.length - 1 ? (
            <button onClick={() => go(idx + 1)} className="btn-primary">
              Next <ArrowRight size={14} />
            </button>
          ) : (
            <button onClick={close} className="btn-primary">
              Finish
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

export default JudgeMode;
