import React, { useState } from 'react';
import { Sparkles, Loader2 } from 'lucide-react';
import GlassCard from '../components/common/GlassCard';
import DataBadge from '../components/common/DataBadge';
import DigitalTwin from '../components/viewer/DigitalTwin';
import FingerprintRadar from '../components/charts/FingerprintRadar';
import WhyThisPersona from '../components/viewer/WhyThisPersona';
import PersonaShiftLab from '../components/viewer/PersonaShiftLab';
import { deriveFeaturesFromInput, simulateRecommend } from '../utils/simulate';
import { isLiveMode, postRecommend, ApiError } from '../api/client';
import type { RecommendRequest, RecommendResponse } from '../types';
import { useAppData } from '../context/AppDataContext';

const LOADING_STEPS = [
  'Reading behavior...',
  'Building behavioral fingerprint...',
  'Locating behavioral community...',
  'Creating personalization...'
];

const GENRE_OPTIONS = ['Action', 'Drama', 'Comedy', 'Thriller', 'Documentary', 'Family', 'Sci-Fi'];

export const DiscoverViewer: React.FC = () => {
  const { personas } = useAppData();
  const [userId, setUserId] = useState('USR-8192');
  const [watchTime, setWatchTime] = useState(32.5);
  const [sessionMins, setSessionMins] = useState(85);
  const [genres, setGenres] = useState<string[]>(['Action', 'Thriller']);

  const [loading, setLoading] = useState(false);
  const [stepIdx, setStepIdx] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<RecommendResponse | null>(null);
  const [input, setInput] = useState<RecommendRequest | null>(null);

  const toggleGenre = (g: string) => {
    setGenres((prev) => (prev.includes(g) ? prev.filter((x) => x !== g) : [...prev, g]));
  };

  const runDiscovery = async () => {
    setError(null);
    setResult(null);
    setLoading(true);
    setStepIdx(0);

    const payload: RecommendRequest = {
      user_id: userId || 'USR-UNKNOWN',
      watch_time_hours: watchTime,
      avg_session_mins: sessionMins,
      top_genres: genres
    };
    setInput(payload);

    for (let i = 0; i < LOADING_STEPS.length; i++) {
      setStepIdx(i);
      await new Promise((r) => setTimeout(r, 420));
    }

    try {
      const res = isLiveMode() ? await postRecommend(payload) : simulateRecommend(payload);
      setResult(res);
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Unexpected error while discovering this viewer.');
    } finally {
      setLoading(false);
    }
  };

  const matchedPersona = result ? personas.find((p) => p.clusterId === result.segment_id) : null;
  const features = input ? deriveFeaturesFromInput(input) : null;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-10">
      <header className="mb-8">
        <span className="kicker">03 · Discover Viewer</span>
        <h1 className="mt-2 font-display text-3xl font-semibold text-slate-50">Discover a Viewer</h1>
        <p className="mt-2 max-w-2xl text-sm text-slate-400">
          Turn viewing behavior into an intelligent audience persona.
        </p>
      </header>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[400px_1fr]">
        {/* FORM */}
        <GlassCard className="h-fit p-6">
          <span className="kicker mb-4 block">Viewer Profile</span>

          <label className="mb-1 block text-xs text-slate-400">User ID</label>
          <input
            value={userId}
            onChange={(e) => setUserId(e.target.value)}
            className="mb-4 w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-slate-100 outline-none focus:border-signal-cyan/50"
          />

          <label className="mb-1 block text-xs text-slate-400">Watch Time (hours)</label>
          <input
            type="number"
            value={watchTime}
            onChange={(e) => setWatchTime(Number(e.target.value))}
            className="mb-4 w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-slate-100 outline-none focus:border-signal-cyan/50"
          />

          <label className="mb-1 block text-xs text-slate-400">Average Session (mins)</label>
          <input
            type="number"
            value={sessionMins}
            onChange={(e) => setSessionMins(Number(e.target.value))}
            className="mb-4 w-full rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-slate-100 outline-none focus:border-signal-cyan/50"
          />

          <label className="mb-2 block text-xs text-slate-400">Top Genres</label>
          <div className="mb-6 flex flex-wrap gap-2">
            {GENRE_OPTIONS.map((g) => (
              <button
                key={g}
                onClick={() => toggleGenre(g)}
                className={
                  genres.includes(g)
                    ? 'rounded-full border border-signal-cyan/40 bg-signal-cyan/10 px-3 py-1 text-xs text-signal-cyan'
                    : 'rounded-full border border-white/10 px-3 py-1 text-xs text-slate-400 hover:border-white/20'
                }
              >
                {g}
              </button>
            ))}
          </div>

          <button onClick={runDiscovery} disabled={loading} className="btn-primary w-full">
            {loading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />}
            Discover Persona
          </button>

          {!isLiveMode() && (
            <p className="mt-3 text-[11px] leading-relaxed text-slate-500">
              No backend connected — persona assignment below is simulated locally with a transparent
              nearest-centroid heuristic against demo persona profiles, not a trained model.
            </p>
          )}
        </GlassCard>

        {/* RESULTS */}
        <div className="space-y-6">
          {loading && (
            <GlassCard className="flex items-center gap-3 p-6">
              <Loader2 size={18} className="animate-spin text-signal-cyan" />
              <span className="text-sm text-slate-300">{LOADING_STEPS[stepIdx]}</span>
            </GlassCard>
          )}

          {error && (
            <GlassCard className="border border-signal-rose/30 p-6 text-sm text-signal-rose">
              {error}
            </GlassCard>
          )}

          {!loading && result && features && matchedPersona && input && (
            <>
              <GlassCard className="p-6">
                <div className="mb-4 flex items-center justify-between">
                  <span className="kicker">Viewer Digital Twin</span>
                  <DataBadge label={isLiveMode() ? 'Live API' : 'Simulated Locally'} />
                </div>
                <DigitalTwin features={features} />
                <div className="mt-4 grid grid-cols-2 gap-4 border-t border-white/[0.06] pt-4 sm:grid-cols-4">
                  <MetaField label="User ID" value={result.user_id} />
                  <MetaField label="Persona" value={result.segment_name} />
                  <MetaField label="Cluster" value={`#${result.segment_id}`} />
                  <MetaField
                    label="Top Genre"
                    value={matchedPersona.topGenre ?? '—'}
                  />
                </div>
              </GlassCard>

              <GlassCard className="p-6">
                <span className="kicker mb-4 block">Behavioral Fingerprint</span>
                <FingerprintRadar features={features} />
              </GlassCard>

              <GlassCard className="p-6">
                <span className="kicker mb-4 block">Why This Persona?</span>
                <WhyThisPersona
                  features={features}
                  persona={matchedPersona}
                  distanceToCentroid={result.distance_to_centroid}
                  isSimulated={!isLiveMode()}
                />
              </GlassCard>

              <GlassCard className="p-6">
                <span className="kicker mb-4 block">What If This Viewer Changes?</span>
                <PersonaShiftLab baseInput={input} baseResult={result} />
              </GlassCard>
            </>
          )}

          {!loading && !result && !error && (
            <GlassCard className="flex h-40 items-center justify-center p-6 text-center text-sm text-slate-500">
              Fill in a viewer profile and click "Discover Persona" to run the pipeline.
            </GlassCard>
          )}
        </div>
      </div>
    </div>
  );
};

const MetaField: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div>
    <p className="text-[10px] uppercase tracking-wide text-slate-500">{label}</p>
    <p className="mt-0.5 truncate font-mono text-sm text-slate-100">{value}</p>
  </div>
);

export default DiscoverViewer;
