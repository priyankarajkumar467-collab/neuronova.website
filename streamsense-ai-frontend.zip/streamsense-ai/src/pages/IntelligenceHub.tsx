import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Compass, Radio, Users, Gauge, Boxes, CheckCircle2 } from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import GlassCard from '../components/common/GlassCard';
import DataBadge from '../components/common/DataBadge';

const PIPELINE = ['Raw Activity', 'Behavior Signals', 'Audience Clusters', 'Viewer Personas', 'Personalization'];

export const IntelligenceHub: React.FC = () => {
  const { personas, modelInfo, viewers, systemStatus } = useAppData();
  const totalViewers = viewers.length;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-10">
      {/* HERO */}
      <div className="grid grid-cols-1 gap-10 lg:grid-cols-2 lg:gap-6">
        <div className="flex flex-col justify-center">
          <span className="kicker mb-4">Containerized OTT Audience Intelligence</span>
          <h1 className="font-display text-4xl font-semibold leading-[1.08] tracking-tight text-slate-50 sm:text-5xl">
            Your Audience
            <br />
            <span className="text-gradient">Is Not One Audience.</span>
          </h1>
          <p className="mt-5 max-w-md text-[15px] leading-relaxed text-slate-400">
            StreamSense AI discovers hidden behavioral communities inside OTT viewing activity and turns
            them into explainable personalization strategies.
          </p>
          <p className="mt-2 text-sm italic text-slate-500">
            “Every Viewer Has a Pattern. We Make It Visible.”
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/discover" className="btn-primary">
              Discover a Viewer <ArrowRight size={16} />
            </Link>
            <Link to="/personas" className="btn-secondary">
              <Compass size={16} /> Explore Personas
            </Link>
          </div>
        </div>

        {/* Animated data-flow pipeline */}
        <GlassCard className="flex flex-col justify-center p-6">
          <span className="kicker mb-4">From Signal to Strategy</span>
          <div className="relative">
            {PIPELINE.map((stage, i) => (
              <div key={stage} className="relative flex items-center gap-4 pb-8 last:pb-0">
                <div className="relative flex flex-col items-center">
                  <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-signal-cyan/30 bg-signal-cyan/10 font-mono text-xs text-signal-cyan">
                    {i + 1}
                  </span>
                  {i < PIPELINE.length - 1 && (
                    <svg width="2" height="32" className="mt-1">
                      <line
                        x1="1"
                        y1="0"
                        x2="1"
                        y2="32"
                        stroke="#4fd8e0"
                        strokeOpacity="0.4"
                        strokeWidth="2"
                        strokeDasharray="4 4"
                        className="animate-flow"
                      />
                    </svg>
                  )}
                </div>
                <span className="font-medium text-slate-200">{stage}</span>
              </div>
            ))}
          </div>
        </GlassCard>
      </div>

      {/* AUDIENCE PULSE RIBBON */}
      <div className="mt-14">
        <div className="mb-3 flex items-center justify-between">
          <span className="kicker">Audience Pulse</span>
          <DataBadge />
        </div>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
          <PulseStat icon={Users} label="Total Viewers" value={totalViewers.toLocaleString()} />
          <PulseStat icon={Compass} label="Discovered Personas" value={String(personas.length)} />
          <PulseStat icon={Boxes} label="Selected K" value={modelInfo.selectedK ? String(modelInfo.selectedK) : '—'} />
          <PulseStat
            icon={Gauge}
            label="Silhouette Score"
            value={modelInfo.silhouetteScore !== null ? modelInfo.silhouetteScore.toFixed(2) : '—'}
          />
          <PulseStat
            icon={CheckCircle2}
            label="Model Status"
            value={systemStatus.model === 'online' ? 'Persisted' : 'Awaiting Model'}
          />
          <PulseStat
            icon={Radio}
            label="API Health"
            value={systemStatus.api === 'online' ? 'Online' : 'API Offline'}
          />
        </div>
      </div>

      {/* Journey teaser */}
      <div className="mt-14">
        <GlassCard className="p-6 sm:p-8">
          <p className="kicker mb-2">The Live-Demo Journey</p>
          <p className="max-w-3xl text-sm leading-relaxed text-slate-400">
            Raw viewer → behavioral fingerprint → discovered persona → why this persona? → personalized
            recommendation → model evidence → system evidence. Start with{' '}
            <Link to="/discover" className="text-signal-cyan underline underline-offset-2">
              Discover Viewer
            </Link>{' '}
            or let <span className="text-slate-200">Judge Mode</span> guide the whole story.
          </p>
        </GlassCard>
      </div>
    </div>
  );
};

const PulseStat: React.FC<{ icon: React.ElementType; label: string; value: string }> = ({
  icon: Icon,
  label,
  value
}) => (
  <GlassCard className="flex flex-col gap-2 p-4">
    <Icon size={16} className="text-signal-cyan" />
    <span className="font-display text-lg font-semibold text-slate-50">{value}</span>
    <span className="text-[11px] uppercase tracking-wide text-slate-500">{label}</span>
  </GlassCard>
);

export default IntelligenceHub;
