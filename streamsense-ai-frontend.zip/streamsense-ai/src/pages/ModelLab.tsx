import React from 'react';
import { useAppData, DEMO_EDGE_CASES } from '../context/AppDataContext';
import GlassCard from '../components/common/GlassCard';
import DataBadge from '../components/common/DataBadge';
import KSelectionCharts from '../components/model/KSelectionCharts';
import ClusterBalance from '../components/model/ClusterBalance';
import FeatureMatrixHeatmap from '../components/model/FeatureMatrixHeatmap';
import PersonaBattle from '../components/model/PersonaBattle';
import EvaluationDimensions from '../components/model/EvaluationDimensions';
import EdgeCaseLab from '../components/model/EdgeCaseLab';

export const ModelLab: React.FC = () => {
  const { modelInfo, kEvaluation, personas, evaluation } = useAppData();

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-10">
      <header className="mb-8">
        <span className="kicker">05 · Model Lab</span>
        <h1 className="mt-2 font-display text-3xl font-semibold text-slate-50">Model Lab</h1>
        <p className="mt-2 max-w-2xl text-sm text-slate-400">Evidence behind every discovered persona.</p>
      </header>

      {/* Algorithm summary */}
      <GlassCard className="mb-8 p-6">
        <div className="mb-4 flex items-center justify-between">
          <span className="kicker">Algorithm & Configuration</span>
          <DataBadge />
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
          <Fact label="Algorithm" value={modelInfo.algorithm} />
          <Fact label="Preprocessing" value={modelInfo.preprocessing} />
          <Fact label="Random Seed" value={modelInfo.randomSeed !== null ? String(modelInfo.randomSeed) : 'Awaiting Model'} />
          <Fact label="Selected K" value={modelInfo.selectedK !== null ? String(modelInfo.selectedK) : 'Awaiting Model'} />
          <Fact
            label="Silhouette Score"
            value={modelInfo.silhouetteScore !== null ? modelInfo.silhouetteScore.toFixed(3) : 'Awaiting Model'}
          />
          <Fact label="Inertia" value={modelInfo.inertia !== null ? modelInfo.inertia.toFixed(1) : 'Awaiting Model'} />
        </div>
      </GlassCard>

      {/* K selection evidence */}
      <GlassCard className="mb-8 p-6">
        <div className="mb-1 flex items-center justify-between">
          <span className="kicker">How Did We Choose K?</span>
          <DataBadge />
        </div>
        <KSelectionCharts points={kEvaluation} selectedK={modelInfo.selectedK} />
        <div className="mt-4 rounded-xl border border-white/[0.06] bg-white/[0.02] p-4 text-sm text-slate-400">
          <span className="font-medium text-slate-200">Why This K? </span>
          K={modelInfo.selectedK} was selected because it maximizes silhouette score (
          {modelInfo.silhouetteScore?.toFixed(2)}) while sitting past the steepest drop in inertia — the
          point where additional clusters stop meaningfully reducing within-cluster variance.
        </div>
      </GlassCard>

      {/* Cluster balance */}
      <GlassCard className="mb-8 p-6">
        <div className="mb-4 flex items-center justify-between">
          <span className="kicker">Is the Audience Well Segmented?</span>
          <DataBadge />
        </div>
        <ClusterBalance personas={personas} />
      </GlassCard>

      {/* Feature matrix */}
      <GlassCard className="mb-8 p-6">
        <div className="mb-4 flex items-center justify-between">
          <span className="kicker">Persona Feature Matrix</span>
          <DataBadge />
        </div>
        <FeatureMatrixHeatmap personas={personas} />
      </GlassCard>

      {/* Persona battle */}
      <GlassCard className="mb-8 p-6">
        <div className="mb-4 flex items-center justify-between">
          <span className="kicker">Persona Battle</span>
          <DataBadge />
        </div>
        <PersonaBattle personas={personas} />
      </GlassCard>

      {/* Evaluation */}
      <GlassCard className="mb-8 p-6">
        <div className="mb-4 flex items-center justify-between">
          <span className="kicker">Model & System Evaluation</span>
          {evaluation.available ? <DataBadge /> : <DataBadge label="Awaiting Evaluation" />}
        </div>
        <EvaluationDimensions dimensions={evaluation.dimensions} />
      </GlassCard>

      {/* Edge cases */}
      <GlassCard className="p-6">
        <div className="mb-4 flex items-center justify-between">
          <span className="kicker">Robustness Lab</span>
          <DataBadge label="Not Tested" />
        </div>
        <EdgeCaseLab cases={DEMO_EDGE_CASES} />
        <p className="mt-4 text-[11px] leading-relaxed text-slate-500">
          These edge cases are executed by the independent Evaluator service against the live API. Results
          shown here are evidence, not decoration — connect the backend to populate real pass/fail status.
        </p>
      </GlassCard>
    </div>
  );
};

const Fact: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <div>
    <p className="text-[10px] uppercase tracking-wide text-slate-500">{label}</p>
    <p className="mt-0.5 truncate font-mono text-sm text-slate-100">{value}</p>
  </div>
);

export default ModelLab;
