import React, { useState } from 'react';
import { useAppData } from '../context/AppDataContext';
import GlassCard from '../components/common/GlassCard';
import DataBadge from '../components/common/DataBadge';
import AudienceUniverse from '../components/charts/AudienceUniverse';
import PersonaOrbField from '../components/persona/PersonaOrbField';
import PersonaPanel from '../components/persona/PersonaPanel';

export const PersonaUniversePage: React.FC = () => {
  const { viewers, personas } = useAppData();
  const [selected, setSelected] = useState<number | null>(personas[0]?.clusterId ?? null);
  const selectedPersona = personas.find((p) => p.clusterId === selected) ?? null;

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-10">
      <header className="mb-8">
        <span className="kicker">02 · Persona Universe</span>
        <h1 className="mt-2 font-display text-3xl font-semibold text-slate-50">Audience Universe</h1>
        <p className="mt-2 max-w-2xl text-sm text-slate-400">
          Each point represents a viewer. Machine learning discovers communities — StreamSense AI turns
          them into human-understandable personas.
        </p>
      </header>

      <GlassCard className="p-5 sm:p-6">
        <div className="mb-3 flex items-center justify-between">
          <span className="kicker">Viewer Distribution</span>
          <DataBadge />
        </div>
        <AudienceUniverse viewers={viewers} personas={personas} />
      </GlassCard>

      <div className="mt-10 mb-4 flex items-center justify-between">
        <div>
          <h2 className="font-display text-2xl font-semibold text-slate-50">Persona Universe</h2>
          <p className="mt-1 text-sm text-slate-400">
            Each orb is a discovered behavioral community. Orb size reflects audience size. Click an orb to
            inspect it.
          </p>
        </div>
        <DataBadge />
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-[1fr_360px]">
        <PersonaOrbField personas={personas} selectedId={selected} onSelect={setSelected} />
        <div className="h-[420px]">
          {selectedPersona ? (
            <PersonaPanel persona={selectedPersona} onClose={() => setSelected(null)} />
          ) : (
            <GlassCard className="flex h-full items-center justify-center p-6 text-center text-sm text-slate-500">
              Select a persona orb to see its full profile.
            </GlassCard>
          )}
        </div>
      </div>
    </div>
  );
};

export default PersonaUniversePage;
