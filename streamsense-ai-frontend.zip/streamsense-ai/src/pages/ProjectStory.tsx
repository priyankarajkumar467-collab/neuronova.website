import React from 'react';
import { ArrowDown } from 'lucide-react';
import GlassCard from '../components/common/GlassCard';

const STORY = [
  { num: '01', title: 'PROBLEM', text: 'Different viewers behave differently.' },
  { num: '02', title: 'DATA', text: 'Viewing activity captures those behavioral differences.' },
  { num: '03', title: 'DISCOVERY', text: 'Unsupervised learning finds behavioral communities.' },
  { num: '04', title: 'INTERPRETATION', text: 'Clusters become understandable viewer personas.' },
  { num: '05', title: 'PERSONALIZATION', text: 'Personas drive transparent recommendation strategies.' },
  { num: '06', title: 'EVIDENCE', text: 'Independent evaluation measures model and system quality.' },
  { num: '07', title: 'DEPLOYMENT', text: 'Docker Compose makes the solution reproducible.' }
];

export const ProjectStory: React.FC = () => (
  <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-10">
    <header className="mb-10 text-center">
      <span className="kicker">07 · Project Story</span>
      <h1 className="mt-2 font-display text-3xl font-semibold text-slate-50">Behavior → Persona → Personalization</h1>
      <p className="mt-2 text-sm text-slate-400">From viewing behavior to explainable personalization.</p>
    </header>

    <div className="flex flex-col items-center">
      {STORY.map((step, i) => (
        <React.Fragment key={step.num}>
          <GlassCard className="w-full p-6 text-center">
            <span className="font-mono text-xs text-signal-cyan">{step.num}</span>
            <h3 className="mt-1 font-display text-lg font-semibold text-slate-50">{step.title}</h3>
            <p className="mt-2 text-sm text-slate-400">{step.text}</p>
          </GlassCard>
          {i < STORY.length - 1 && <ArrowDown size={18} className="my-3 text-signal-cyan/50" />}
        </React.Fragment>
      ))}
    </div>

    <div className="mt-12 text-center">
      <p className="font-display text-2xl font-semibold text-gradient">STREAMSENSE AI</p>
      <p className="mt-1 text-sm italic text-slate-500">“Behavior → Persona → Personalization”</p>
    </div>
  </div>
);

export default ProjectStory;
