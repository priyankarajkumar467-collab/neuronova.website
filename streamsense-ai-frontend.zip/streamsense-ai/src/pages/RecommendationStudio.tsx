import React, { useState } from 'react';
import { Plus, Equal, ChevronDown, ChevronUp } from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import GlassCard from '../components/common/GlassCard';
import DataBadge from '../components/common/DataBadge';
import PersonalizationCompass from '../components/viewer/PersonalizationCompass';
import { deriveCompassWeights } from '../utils/compass';

export const RecommendationStudio: React.FC = () => {
  const { personas, recommendationsByCluster } = useAppData();
  const [selectedId, setSelectedId] = useState(personas[0]?.clusterId ?? 0);
  const [openReason, setOpenReason] = useState<string | null>(null);

  const persona = personas.find((p) => p.clusterId === selectedId) ?? personas[0];
  const recs = recommendationsByCluster[selectedId] ?? [];
  const compass = deriveCompassWeights(persona.features);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-10">
      <header className="mb-8 flex flex-wrap items-start justify-between gap-4">
        <div>
          <span className="kicker">04 · Recommendation Studio</span>
          <h1 className="mt-2 font-display text-3xl font-semibold text-slate-50">
            From Persona to Personalization
          </h1>
          <p className="mt-2 max-w-xl text-sm text-slate-400">
            Explainable, rule-based personalization built directly on top of discovered behavioral
            communities.
          </p>
        </div>
        <select
          value={selectedId}
          onChange={(e) => setSelectedId(Number(e.target.value))}
          className="rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2 text-sm text-slate-100"
        >
          {personas.map((p) => (
            <option key={p.clusterId} value={p.clusterId}>
              {p.name}
            </option>
          ))}
        </select>
      </header>

      {/* Equation */}
      <GlassCard className="mb-8 p-6">
        <div className="flex flex-col items-center justify-center gap-3 text-center sm:flex-row sm:gap-5">
          <EquationChip label="Viewer Persona" value={persona.name} />
          <Plus size={18} className="text-slate-500" />
          <EquationChip label="Genre Preference" value={persona.topGenre ?? '—'} />
          <Plus size={18} className="text-slate-500" />
          <EquationChip label="Behavior" value="Engagement & Session Profile" />
          <Equal size={18} className="text-slate-500" />
          <EquationChip
            label="Personalization Strategy"
            value="Explainable Rule-Based Personalization"
            highlight
          />
        </div>
      </GlassCard>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-[1fr_320px]">
        <div>
          <div className="mb-3 flex items-center justify-between">
            <span className="kicker">Recommended For This Persona</span>
            <DataBadge />
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            {recs.map((rec, i) => (
              <GlassCard key={i} className="p-5">
                <div className="mb-3 flex h-28 items-center justify-center rounded-xl bg-gradient-to-br from-signal-cyan/15 via-signal-violet/10 to-transparent">
                  <span className="font-display text-sm text-slate-300">{rec.genre ?? 'Featured'}</span>
                </div>
                <h3 className="font-medium text-slate-100">{rec.title}</h3>
                {rec.genre && <p className="text-xs text-slate-500">{rec.genre}</p>}

                <button
                  onClick={() => setOpenReason(openReason === rec.title ? null : rec.title)}
                  className="mt-3 flex items-center gap-1 text-xs text-signal-cyan"
                >
                  Why This?
                  {openReason === rec.title ? <ChevronUp size={13} /> : <ChevronDown size={13} />}
                </button>
                {openReason === rec.title && (
                  <p className="mt-2 rounded-lg bg-white/[0.03] p-3 text-xs leading-relaxed text-slate-400">
                    {rec.reason ?? 'Matched via the documented rule-based personalization layer.'}
                  </p>
                )}
              </GlassCard>
            ))}
            {recs.length === 0 && (
              <GlassCard className="p-6 text-sm text-slate-500 sm:col-span-2">
                No recommendations available for this persona yet.
              </GlassCard>
            )}
          </div>
        </div>

        <GlassCard className="h-fit p-6">
          <span className="kicker mb-1 block">Personalization Compass</span>
          <p className="mb-4 text-[11px] leading-relaxed text-slate-500">
            A visual reading of this persona's recommendation strategy, derived from documented rules
            mapping behavioral features to direction weights.
          </p>
          <PersonalizationCompass weights={compass} />
        </GlassCard>
      </div>
    </div>
  );
};

const EquationChip: React.FC<{ label: string; value: string; highlight?: boolean }> = ({
  label,
  value,
  highlight
}) => (
  <div
    className={
      highlight
        ? 'rounded-xl border border-signal-cyan/30 bg-signal-cyan/10 px-4 py-3'
        : 'rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3'
    }
  >
    <p className="text-[10px] uppercase tracking-wide text-slate-500">{label}</p>
    <p className={highlight ? 'text-sm font-medium text-signal-cyan' : 'text-sm font-medium text-slate-200'}>
      {value}
    </p>
  </div>
);

export default RecommendationStudio;
