import React from 'react';
import { Database, Cpu, Server, ShieldCheck, ArrowDown, Terminal } from 'lucide-react';
import { useAppData } from '../context/AppDataContext';
import GlassCard from '../components/common/GlassCard';
import StatusPill from '../components/common/StatusPill';

export const SystemPulse: React.FC = () => {
  const { systemStatus } = useAppData();

  const stages = [
    { icon: Database, label: 'Dataset' },
    { icon: Cpu, label: 'Trainer' },
    { icon: ShieldCheck, label: 'Persisted Model' },
    { icon: Server, label: 'API' },
    { icon: ShieldCheck, label: 'Evaluator' },
    { icon: Database, label: 'metrics.json' }
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-10">
      <header className="mb-8">
        <span className="kicker">06 · System Pulse</span>
        <h1 className="mt-2 font-display text-3xl font-semibold text-slate-50">System Pulse</h1>
        <p className="mt-2 max-w-2xl text-sm text-slate-400">
          From raw viewer activity to reproducible intelligence.
        </p>
      </header>

      {/* Architecture flow */}
      <GlassCard className="mb-8 p-8">
        <div className="mx-auto flex max-w-xs flex-col items-center">
          {stages.map((s, i) => (
            <React.Fragment key={s.label}>
              <div className="flex w-full items-center gap-3 rounded-xl border border-white/[0.06] bg-white/[0.02] px-4 py-3">
                <s.icon size={16} className="text-signal-cyan" />
                <span className="text-sm text-slate-200">{s.label}</span>
              </div>
              {i < stages.length - 1 && (
                <ArrowDown size={16} className="my-2 animate-pulseGlow text-signal-cyan/60" />
              )}
            </React.Fragment>
          ))}
        </div>
      </GlassCard>

      {/* Three-service status */}
      <div className="mb-8 grid grid-cols-1 gap-5 md:grid-cols-3">
        <ServiceCard
          title="TRAINER"
          purpose="Trains and persists the clustering pipeline."
          status={systemStatus.model}
        />
        <ServiceCard
          title="API"
          purpose="Serves personas and personalized recommendations."
          status={systemStatus.api}
        />
        <ServiceCard
          title="EVALUATOR"
          purpose="Independently verifies model and service quality."
          status={systemStatus.evaluator}
        />
      </div>
      <p className="mb-8 text-[11px] leading-relaxed text-slate-500">
        Status above reflects what the frontend can verify via the API layer. It does not, by itself, prove
        the underlying Docker containers are healthy — that requires backend-exposed health/status data.
      </p>

      {/* One-command deployment */}
      <GlassCard className="p-8 text-center">
        <p className="kicker mb-2">Reproducible Intelligence</p>
        <h2 className="font-display text-2xl font-semibold text-slate-50">
          One Command. Three Services.
          <br />
          Reproducible Intelligence.
        </h2>
        <div className="mx-auto mt-5 flex max-w-md items-center gap-2 rounded-xl border border-white/10 bg-black/40 px-4 py-3 font-mono text-sm text-signal-emerald">
          <Terminal size={15} />
          docker compose up --build
        </div>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2 font-mono text-xs text-slate-400">
          <span className="rounded-full border border-white/10 px-3 py-1">TRAINER</span>
          <span>→</span>
          <span className="rounded-full border border-white/10 px-3 py-1">MODEL</span>
          <span>→</span>
          <span className="rounded-full border border-white/10 px-3 py-1">API</span>
          <span>→</span>
          <span className="rounded-full border border-white/10 px-3 py-1">EVALUATOR</span>
        </div>
      </GlassCard>
    </div>
  );
};

const ServiceCard: React.FC<{ title: string; purpose: string; status: any }> = ({ title, purpose, status }) => (
  <GlassCard className="flex flex-col gap-3 p-5">
    <div className="flex items-center justify-between">
      <span className="font-mono text-sm tracking-wide text-slate-200">{title}</span>
    </div>
    <p className="text-xs leading-relaxed text-slate-500">{purpose}</p>
    <StatusPill label={title} status={status} />
  </GlassCard>
);

export default SystemPulse;
