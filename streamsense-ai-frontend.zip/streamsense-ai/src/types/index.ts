// ============================================================
// StreamSense AI — Shared Types
// These mirror the REAL backend contract (Trainer / API / Evaluator).
// Nothing here is a guarantee that a field is populated — always
// check the corresponding `source` / status flags before trusting a value.
// ============================================================

export type DataSource = 'demo' | 'live';

export type ServiceStatus = 'online' | 'offline' | 'degraded' | 'unknown' | 'loading';

export interface SystemStatus {
  dataset: ServiceStatus;
  model: ServiceStatus;
  api: ServiceStatus;
  evaluator: ServiceStatus;
  source: DataSource;
}

// ---- Behavioral features (only ones actually used by the model) ----
export interface BehaviorFeatureVector {
  engagement?: number; // 0-1 normalized
  sessionDepth?: number;
  frequency?: number;
  genreDiversity?: number;
  completion?: number;
  exploration?: number;
  weekendActivity?: number;
}

export type FeatureKey = keyof BehaviorFeatureVector;

export const FEATURE_LABELS: Record<FeatureKey, string> = {
  engagement: 'Engagement',
  sessionDepth: 'Session Depth',
  frequency: 'Frequency',
  genreDiversity: 'Genre Diversity',
  completion: 'Completion',
  exploration: 'Exploration',
  weekendActivity: 'Weekend Activity'
};

// ---- Persona / Cluster ----
export interface Persona {
  clusterId: number;
  name: string;
  audienceSize: number;
  audienceShare: number; // 0-1
  topGenre?: string;
  features: BehaviorFeatureVector;
  narrative?: string; // derived from real cluster characteristics, never randomly generated
  isDemo: boolean;
}

// ---- Viewer (a single user activity record) ----
export interface Viewer {
  userId: string;
  watchTimeHours: number;
  avgSessionMins: number;
  topGenres: string[];
  clusterId: number;
  projection?: { x: number; y: number; isPCA: boolean };
}

// ---- /recommend request/response (schema mirrors backend exactly) ----
export interface RecommendRequest {
  user_id: string;
  watch_time_hours: number;
  top_genres: string[];
  avg_session_mins: number;
}

export interface RecommendationItem {
  title: string;
  genre?: string;
  reason?: string;
}

export interface RecommendResponse {
  user_id: string;
  segment_id: number;
  segment_name: string;
  recommendations: RecommendationItem[] | string[];
  distance_to_centroid: number;
}

// ---- /health ----
export interface HealthResponse {
  status: 'ok' | 'error';
  model_loaded: boolean;
}

// ---- Model Lab ----
export interface ModelInfo {
  algorithm: string;
  preprocessing: string;
  randomSeed: number | null;
  selectedK: number | null;
  silhouetteScore: number | null;
  inertia: number | null;
  available: boolean;
}

export interface KEvaluationPoint {
  k: number;
  silhouette: number;
  inertia: number;
}

// ---- Evaluation (metrics.json) ----
export type EvalStatus = 'pass' | 'warning' | 'fail' | 'not_evaluated';

export interface EvaluationDimension {
  name: string;
  status: EvalStatus;
  detail?: string;
}

export interface EdgeCaseResult {
  name: string;
  status: 'pass' | 'fail' | 'not_tested';
  detail?: string;
}

export interface EvaluationReport {
  available: boolean;
  generatedAt?: string;
  dimensions: EvaluationDimension[];
  edgeCases: EdgeCaseResult[];
}

// ---- Personalization Compass ----
export type CompassDirection = 'familiar' | 'discover' | 'trending' | 'quickWatch';

export interface CompassWeights {
  familiar: number;
  discover: number;
  trending: number;
  quickWatch: number;
}
