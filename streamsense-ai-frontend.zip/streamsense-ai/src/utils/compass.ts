import type { BehaviorFeatureVector, CompassWeights } from '../types';

/**
 * Deterministic, documented rule mapping — NOT a model.
 * This is the "explainable rule-based personalization" layer described
 * in the product spec. Each direction is derived from a single feature:
 *
 *   FAMILIAR    <- (1 - genreDiversity)   (genre-loyal viewers lean familiar)
 *   DISCOVER    <- exploration
 *   TRENDING    <- weekendActivity
 *   QUICK_WATCH <- (1 - sessionDepth)     (short sessions lean quick-watch)
 */
export function deriveCompassWeights(features: BehaviorFeatureVector): CompassWeights {
  const genreDiversity = features.genreDiversity ?? 0.5;
  const exploration = features.exploration ?? 0.5;
  const weekendActivity = features.weekendActivity ?? 0.5;
  const sessionDepth = features.sessionDepth ?? 0.5;

  return {
    familiar: clamp(1 - genreDiversity),
    discover: clamp(exploration),
    trending: clamp(weekendActivity),
    quickWatch: clamp(1 - sessionDepth)
  };
}

function clamp(v: number) {
  return Math.max(0.05, Math.min(1, v));
}
