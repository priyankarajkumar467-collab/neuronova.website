import type { BehaviorFeatureVector, Persona, RecommendRequest, RecommendResponse } from '../types';
import { DEMO_PERSONAS, DEMO_RECOMMENDATIONS_BY_CLUSTER } from '../data/demoData';

/**
 * DEMO-MODE ONLY.
 * This is a lightweight, transparent heuristic used purely so the interface
 * has something to show when no backend is connected. It is NOT the real
 * trained KMeans pipeline and must never be presented as such — every
 * caller of this function is expected to render a "Demo Data" /
 * "Simulated locally" badge next to its output.
 */
export function deriveFeaturesFromInput(input: RecommendRequest): BehaviorFeatureVector {
  const engagement = clamp(input.watch_time_hours / 60);
  const sessionDepth = clamp(input.avg_session_mins / 120);
  const genreDiversity = clamp(input.top_genres.length / 4);
  const frequency = clamp((input.watch_time_hours / Math.max(input.avg_session_mins / 60, 0.25)) / 40);
  return {
    engagement,
    sessionDepth,
    genreDiversity,
    frequency,
    completion: clamp(0.4 + sessionDepth * 0.4),
    exploration: clamp(genreDiversity * 0.9),
    weekendActivity: clamp(0.4 + engagement * 0.2)
  };
}

function clamp(v: number) {
  return Math.max(0, Math.min(1, v));
}

function distance(a: BehaviorFeatureVector, b: BehaviorFeatureVector): number {
  const keys = Object.keys(a) as (keyof BehaviorFeatureVector)[];
  let sum = 0;
  let n = 0;
  keys.forEach((k) => {
    const av = a[k];
    const bv = b[k];
    if (typeof av === 'number' && typeof bv === 'number') {
      sum += (av - bv) ** 2;
      n++;
    }
  });
  return n > 0 ? Math.sqrt(sum / n) : 0;
}

export function simulateRecommend(input: RecommendRequest, personas: Persona[] = DEMO_PERSONAS): RecommendResponse {
  const features = deriveFeaturesFromInput(input);
  let best = personas[0];
  let bestDist = Infinity;
  personas.forEach((p) => {
    const d = distance(features, p.features);
    if (d < bestDist) {
      bestDist = d;
      best = p;
    }
  });

  return {
    user_id: input.user_id,
    segment_id: best.clusterId,
    segment_name: best.name,
    recommendations: DEMO_RECOMMENDATIONS_BY_CLUSTER[best.clusterId] ?? [],
    distance_to_centroid: Math.round(bestDist * 1000) / 1000
  };
}

export function distanceLabel(distance: number): string {
  if (distance < 0.15) return 'Very Close';
  if (distance < 0.3) return 'Close';
  if (distance < 0.5) return 'Moderate';
  return 'Distant';
}
