/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        void: {
          950: '#05070d',
          900: '#0a0e18',
          850: '#0d1220',
          800: '#111827',
          700: '#1a2235'
        },
        signal: {
          cyan: '#4fd8e0',
          violet: '#8b7cf6',
          amber: '#f5b95e',
          rose: '#f47b9c',
          emerald: '#4fe0a8'
        }
      },
      fontFamily: {
        display: ['"Space Grotesk"', 'Sora', 'ui-sans-serif', 'system-ui'],
        body: ['"Inter"', 'ui-sans-serif', 'system-ui'],
        mono: ['"JetBrains Mono"', 'ui-monospace', 'SFMono-Regular']
      },
      boxShadow: {
        glow: '0 0 0 1px rgba(79,216,224,0.15), 0 0 24px -4px rgba(79,216,224,0.35)',
        'glow-violet': '0 0 0 1px rgba(139,124,246,0.18), 0 0 28px -6px rgba(139,124,246,0.45)',
        panel: '0 1px 0 0 rgba(255,255,255,0.04) inset, 0 20px 60px -20px rgba(0,0,0,0.6)'
      },
      backgroundImage: {
        'grid-fade':
          'radial-gradient(ellipse 80% 60% at 50% -10%, rgba(79,216,224,0.12), transparent), radial-gradient(ellipse 60% 50% at 100% 0%, rgba(139,124,246,0.10), transparent)'
      },
      keyframes: {
        pulseGlow: {
          '0%, 100%': { opacity: '0.55' },
          '50%': { opacity: '1' }
        },
        flow: {
          '0%': { strokeDashoffset: '40' },
          '100%': { strokeDashoffset: '0' }
        },
        floatSlow: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-8px)' }
        }
      },
      animation: {
        pulseGlow: 'pulseGlow 2.4s ease-in-out infinite',
        flow: 'flow 1.2s linear infinite',
        floatSlow: 'floatSlow 6s ease-in-out infinite'
      }
    }
  },
  plugins: []
};
